# Auto-generated argument completers for parameters of SDK ConstantClass-derived type used in cmdlets.
# Do not modify this file; it may be overwritten during version upgrades.

$psMajorVersion = $PSVersionTable.PSVersion.Major
if ($psMajorVersion -eq 2) 
{ 
	Write-Verbose "Dynamic argument completion not supported in PowerShell version 2; skipping load."
	return 
}

# PowerShell's native Register-ArgumentCompleter cmdlet is available on v5.0 or higher. For lower
# version, we can use the version in the TabExpansion++ module if installed.
$registrationCmdletAvailable = ($psMajorVersion -ge 5) -Or !((Get-Command Register-ArgumentCompleter -ea Ignore) -eq $null)

# internal function to perform the registration using either cmdlet or manipulation
# of the options table
function _awsArgumentCompleterRegistration()
{
    param
    (
        [scriptblock]$scriptBlock,
        [hashtable]$param2CmdletsMap
    )

    if ($registrationCmdletAvailable)
    {
        foreach ($paramName in $param2CmdletsMap.Keys)
        {
             $args = @{
                "ScriptBlock" = $scriptBlock
                "Parameter" = $paramName
            }

            $cmdletNames = $param2CmdletsMap[$paramName]
            if ($cmdletNames -And $cmdletNames.Length -gt 0)
            {
                $args["Command"] = $cmdletNames
            }

            Register-ArgumentCompleter @args
        }
    }
    else
    {
        if (-not $global:options) { $global:options = @{ CustomArgumentCompleters = @{ }; NativeArgumentCompleters = @{ } } }

        foreach ($paramName in $param2CmdletsMap.Keys)
        {
            $cmdletNames = $param2CmdletsMap[$paramName]

            if ($cmdletNames -And $cmdletNames.Length -gt 0)
            {
                foreach ($cn in $cmdletNames)
                {
                    $fqn =  [string]::Concat($cn, ":", $paramName)
                    $global:options['CustomArgumentCompleters'][$fqn] = $scriptBlock
                }
            }
            else
            {
                $global:options['CustomArgumentCompleters'][$paramName] = $scriptBlock
            }
        }

        $function:tabexpansion2 = $function:tabexpansion2 -replace 'End\r\n{', 'End { if ($null -ne $options) { $options += $global:options} else {$options = $global:options}'
    }
}

# To allow for same-name parameters of different ConstantClass-derived types 
# each completer function checks on command name concatenated with parameter name.
# Additionally, the standard code pattern for completers is to pipe through 
# sort-object after filtering against $wordToComplete but we omit this as our members 
# are already sorted.

# Argument completions for service AWS CodeBuild


$CB_Completers = {
    param($commandName, $parameterName, $wordToComplete, $commandAst, $fakeBoundParameter)

    switch ($("$commandName/$parameterName"))
    {
        # Amazon.CodeBuild.ArtifactNamespace
        {
            ($_ -eq "New-CBProject/Artifacts_NamespaceType") -Or
            ($_ -eq "Update-CBProject/Artifacts_NamespaceType") -Or
            ($_ -eq "Start-CBBatch/ArtifactsOverride_NamespaceType") -Or
            ($_ -eq "Start-CBBuild/ArtifactsOverride_NamespaceType")
        }
        {
            $v = "BUILD_ID","NONE"
            break
        }

        # Amazon.CodeBuild.ArtifactPackaging
        {
            ($_ -eq "New-CBProject/Artifacts_Packaging") -Or
            ($_ -eq "Update-CBProject/Artifacts_Packaging") -Or
            ($_ -eq "Start-CBBatch/ArtifactsOverride_Packaging") -Or
            ($_ -eq "Start-CBBuild/ArtifactsOverride_Packaging")
        }
        {
            $v = "NONE","ZIP"
            break
        }

        # Amazon.CodeBuild.ArtifactsType
        {
            ($_ -eq "New-CBProject/Artifacts_Type") -Or
            ($_ -eq "Update-CBProject/Artifacts_Type") -Or
            ($_ -eq "Start-CBBatch/ArtifactsOverride_Type") -Or
            ($_ -eq "Start-CBBuild/ArtifactsOverride_Type")
        }
        {
            $v = "CODEPIPELINE","NO_ARTIFACTS","S3"
            break
        }

        # Amazon.CodeBuild.AuthType
        "Import-CBSourceCredential/AuthType"
        {
            $v = "BASIC_AUTH","CODECONNECTIONS","OAUTH","PERSONAL_ACCESS_TOKEN","SECRETS_MANAGER"
            break
        }

        # Amazon.CodeBuild.BatchReportModeType
        {
            ($_ -eq "New-CBProject/BuildBatchConfig_BatchReportMode") -Or
            ($_ -eq "Update-CBProject/BuildBatchConfig_BatchReportMode") -Or
            ($_ -eq "Start-CBBatch/BuildBatchConfigOverride_BatchReportMode")
        }
        {
            $v = "REPORT_AGGREGATED_BATCH","REPORT_INDIVIDUAL_BUILDS"
            break
        }

        # Amazon.CodeBuild.BucketOwnerAccess
        {
            ($_ -eq "New-CBProject/Artifacts_BucketOwnerAccess") -Or
            ($_ -eq "Update-CBProject/Artifacts_BucketOwnerAccess") -Or
            ($_ -eq "Start-CBBatch/ArtifactsOverride_BucketOwnerAccess") -Or
            ($_ -eq "Start-CBBuild/ArtifactsOverride_BucketOwnerAccess") -Or
            ($_ -eq "New-CBProject/S3Logs_BucketOwnerAccess") -Or
            ($_ -eq "Start-CBBatch/S3Logs_BucketOwnerAccess") -Or
            ($_ -eq "Start-CBBuild/S3Logs_BucketOwnerAccess") -Or
            ($_ -eq "Update-CBProject/S3Logs_BucketOwnerAccess")
        }
        {
            $v = "FULL","NONE","READ_ONLY"
            break
        }

        # Amazon.CodeBuild.CacheType
        {
            ($_ -eq "New-CBProject/Cache_Type") -Or
            ($_ -eq "Update-CBProject/Cache_Type") -Or
            ($_ -eq "Start-CBBatch/CacheOverride_Type") -Or
            ($_ -eq "Start-CBBuild/CacheOverride_Type")
        }
        {
            $v = "LOCAL","NO_CACHE","S3"
            break
        }

        # Amazon.CodeBuild.ComputeType
        {
            ($_ -eq "New-CBFleet/ComputeType") -Or
            ($_ -eq "Update-CBFleet/ComputeType") -Or
            ($_ -eq "Start-CBBatch/ComputeTypeOverride") -Or
            ($_ -eq "Start-CBBuild/ComputeTypeOverride") -Or
            ($_ -eq "New-CBProject/Environment_ComputeType") -Or
            ($_ -eq "Update-CBProject/Environment_ComputeType")
        }
        {
            $v = "ATTRIBUTE_BASED_COMPUTE","BUILD_GENERAL1_2XLARGE","BUILD_GENERAL1_LARGE","BUILD_GENERAL1_MEDIUM","BUILD_GENERAL1_SMALL","BUILD_GENERAL1_XLARGE","BUILD_LAMBDA_10GB","BUILD_LAMBDA_1GB","BUILD_LAMBDA_2GB","BUILD_LAMBDA_4GB","BUILD_LAMBDA_8GB"
            break
        }

        # Amazon.CodeBuild.CredentialProviderType
        {
            ($_ -eq "New-CBProject/RegistryCredential_CredentialProvider") -Or
            ($_ -eq "Update-CBProject/RegistryCredential_CredentialProvider") -Or
            ($_ -eq "Start-CBBatch/RegistryCredentialOverride_CredentialProvider") -Or
            ($_ -eq "Start-CBBuild/RegistryCredentialOverride_CredentialProvider")
        }
        {
            $v = "SECRETS_MANAGER"
            break
        }

        # Amazon.CodeBuild.EnvironmentType
        {
            ($_ -eq "New-CBProject/Environment_Type") -Or
            ($_ -eq "Update-CBProject/Environment_Type") -Or
            ($_ -eq "New-CBFleet/EnvironmentType") -Or
            ($_ -eq "Update-CBFleet/EnvironmentType") -Or
            ($_ -eq "Start-CBBatch/EnvironmentTypeOverride") -Or
            ($_ -eq "Start-CBBuild/EnvironmentTypeOverride")
        }
        {
            $v = "ARM_CONTAINER","ARM_EC2","ARM_LAMBDA_CONTAINER","LINUX_CONTAINER","LINUX_EC2","LINUX_GPU_CONTAINER","LINUX_LAMBDA_CONTAINER","MAC_ARM","WINDOWS_CONTAINER","WINDOWS_EC2","WINDOWS_SERVER_2019_CONTAINER"
            break
        }

        # Amazon.CodeBuild.FleetOverflowBehavior
        {
            ($_ -eq "New-CBFleet/OverflowBehavior") -Or
            ($_ -eq "Update-CBFleet/OverflowBehavior")
        }
        {
            $v = "ON_DEMAND","QUEUE"
            break
        }

        # Amazon.CodeBuild.FleetProxyRuleBehavior
        {
            ($_ -eq "New-CBFleet/ProxyConfiguration_DefaultBehavior") -Or
            ($_ -eq "Update-CBFleet/ProxyConfiguration_DefaultBehavior")
        }
        {
            $v = "ALLOW_ALL","DENY_ALL"
            break
        }

        # Amazon.CodeBuild.FleetScalingType
        {
            ($_ -eq "New-CBFleet/ScalingConfiguration_ScalingType") -Or
            ($_ -eq "Update-CBFleet/ScalingConfiguration_ScalingType")
        }
        {
            $v = "TARGET_TRACKING_SCALING"
            break
        }

        # Amazon.CodeBuild.FleetSortByType
        "Get-CBFleetList/SortBy"
        {
            $v = "CREATED_TIME","LAST_MODIFIED_TIME","NAME"
            break
        }

        # Amazon.CodeBuild.ImagePullCredentialsType
        {
            ($_ -eq "New-CBProject/Environment_ImagePullCredentialsType") -Or
            ($_ -eq "Update-CBProject/Environment_ImagePullCredentialsType") -Or
            ($_ -eq "Start-CBBatch/ImagePullCredentialsTypeOverride") -Or
            ($_ -eq "Start-CBBuild/ImagePullCredentialsTypeOverride")
        }
        {
            $v = "CODEBUILD","SERVICE_ROLE"
            break
        }

        # Amazon.CodeBuild.LogsConfigStatusType
        {
            ($_ -eq "New-CBProject/CloudWatchLogs_Status") -Or
            ($_ -eq "Start-CBBatch/CloudWatchLogs_Status") -Or
            ($_ -eq "Start-CBBuild/CloudWatchLogs_Status") -Or
            ($_ -eq "Update-CBProject/CloudWatchLogs_Status") -Or
            ($_ -eq "New-CBProject/S3Logs_Status") -Or
            ($_ -eq "Start-CBBatch/S3Logs_Status") -Or
            ($_ -eq "Start-CBBuild/S3Logs_Status") -Or
            ($_ -eq "Update-CBProject/S3Logs_Status")
        }
        {
            $v = "DISABLED","ENABLED"
            break
        }

        # Amazon.CodeBuild.MachineType
        {
            ($_ -eq "New-CBFleet/ComputeConfiguration_MachineType") -Or
            ($_ -eq "New-CBProject/ComputeConfiguration_MachineType") -Or
            ($_ -eq "Update-CBFleet/ComputeConfiguration_MachineType") -Or
            ($_ -eq "Update-CBProject/ComputeConfiguration_MachineType")
        }
        {
            $v = "GENERAL","NVME"
            break
        }

        # Amazon.CodeBuild.ProjectSortByType
        "Get-CBProjectList/SortBy"
        {
            $v = "CREATED_TIME","LAST_MODIFIED_TIME","NAME"
            break
        }

        # Amazon.CodeBuild.ProjectVisibilityType
        "Update-CBProjectVisibility/ProjectVisibility"
        {
            $v = "PRIVATE","PUBLIC_READ"
            break
        }

        # Amazon.CodeBuild.ReportCodeCoverageSortByType
        "Get-CBCodeCoverage/SortBy"
        {
            $v = "FILE_PATH","LINE_COVERAGE_PERCENTAGE"
            break
        }

        # Amazon.CodeBuild.ReportExportConfigType
        {
            ($_ -eq "New-CBReportGroup/ExportConfig_ExportConfigType") -Or
            ($_ -eq "Update-CBReportGroup/ExportConfig_ExportConfigType")
        }
        {
            $v = "NO_EXPORT","S3"
            break
        }

        # Amazon.CodeBuild.ReportGroupSortByType
        "Get-CBReportGroupList/SortBy"
        {
            $v = "CREATED_TIME","LAST_MODIFIED_TIME","NAME"
            break
        }

        # Amazon.CodeBuild.ReportGroupTrendFieldType
        "Get-CBReportGroupTrend/TrendField"
        {
            $v = "BRANCHES_COVERED","BRANCHES_MISSED","BRANCH_COVERAGE","DURATION","LINES_COVERED","LINES_MISSED","LINE_COVERAGE","PASS_RATE","TOTAL"
            break
        }

        # Amazon.CodeBuild.ReportPackagingType
        {
            ($_ -eq "New-CBReportGroup/S3Destination_Packaging") -Or
            ($_ -eq "Update-CBReportGroup/S3Destination_Packaging")
        }
        {
            $v = "NONE","ZIP"
            break
        }

        # Amazon.CodeBuild.ReportStatusType
        {
            ($_ -eq "Get-CBReportList/Filter_Status") -Or
            ($_ -eq "Get-CBReportsForReportGroupList/Filter_Status")
        }
        {
            $v = "DELETING","FAILED","GENERATING","INCOMPLETE","SUCCEEDED"
            break
        }

        # Amazon.CodeBuild.ReportType
        "New-CBReportGroup/Type"
        {
            $v = "CODE_COVERAGE","TEST"
            break
        }

        # Amazon.CodeBuild.RetryBuildBatchType
        "Redo-CBBatch/RetryType"
        {
            $v = "RETRY_ALL_BUILDS","RETRY_FAILED_BUILDS"
            break
        }

        # Amazon.CodeBuild.ServerType
        "Import-CBSourceCredential/ServerType"
        {
            $v = "BITBUCKET","GITHUB","GITHUB_ENTERPRISE","GITLAB","GITLAB_SELF_MANAGED"
            break
        }

        # Amazon.CodeBuild.SharedResourceSortByType
        {
            ($_ -eq "Get-CBSharedProjectList/SortBy") -Or
            ($_ -eq "Get-CBSharedReportGroupList/SortBy")
        }
        {
            $v = "ARN","MODIFIED_TIME"
            break
        }

        # Amazon.CodeBuild.SortOrderType
        {
            ($_ -eq "Get-CBBatchIdList/SortOrder") -Or
            ($_ -eq "Get-CBBatchIdListForProject/SortOrder") -Or
            ($_ -eq "Get-CBBuildIdList/SortOrder") -Or
            ($_ -eq "Get-CBBuildIdListForProject/SortOrder") -Or
            ($_ -eq "Get-CBCodeCoverage/SortOrder") -Or
            ($_ -eq "Get-CBFleetList/SortOrder") -Or
            ($_ -eq "Get-CBProjectList/SortOrder") -Or
            ($_ -eq "Get-CBReportGroupList/SortOrder") -Or
            ($_ -eq "Get-CBReportList/SortOrder") -Or
            ($_ -eq "Get-CBReportsForReportGroupList/SortOrder") -Or
            ($_ -eq "Get-CBSharedProjectList/SortOrder") -Or
            ($_ -eq "Get-CBSharedReportGroupList/SortOrder")
        }
        {
            $v = "ASCENDING","DESCENDING"
            break
        }

        # Amazon.CodeBuild.SourceAuthType
        {
            ($_ -eq "New-CBProject/Auth_Type") -Or
            ($_ -eq "Update-CBProject/Auth_Type") -Or
            ($_ -eq "Start-CBBatch/SourceAuthOverride_Type") -Or
            ($_ -eq "Start-CBBuild/SourceAuthOverride_Type")
        }
        {
            $v = "CODECONNECTIONS","OAUTH","SECRETS_MANAGER"
            break
        }

        # Amazon.CodeBuild.SourceType
        {
            ($_ -eq "New-CBProject/Source_Type") -Or
            ($_ -eq "Update-CBProject/Source_Type") -Or
            ($_ -eq "Start-CBBatch/SourceTypeOverride") -Or
            ($_ -eq "Start-CBBuild/SourceTypeOverride")
        }
        {
            $v = "BITBUCKET","CODECOMMIT","CODEPIPELINE","GITHUB","GITHUB_ENTERPRISE","GITLAB","GITLAB_SELF_MANAGED","NO_SOURCE","S3"
            break
        }

        # Amazon.CodeBuild.StatusType
        {
            ($_ -eq "Get-CBBatchIdList/Filter_Status") -Or
            ($_ -eq "Get-CBBatchIdListForProject/Filter_Status")
        }
        {
            $v = "FAILED","FAULT","IN_PROGRESS","STOPPED","SUCCEEDED","TIMED_OUT"
            break
        }

        # Amazon.CodeBuild.WebhookBuildType
        {
            ($_ -eq "New-CBWebhook/BuildType") -Or
            ($_ -eq "Update-CBWebhook/BuildType")
        }
        {
            $v = "BUILD","BUILD_BATCH","RUNNER_BUILDKITE_BUILD"
            break
        }

        # Amazon.CodeBuild.WebhookScopeType
        "New-CBWebhook/ScopeConfiguration_Scope"
        {
            $v = "GITHUB_GLOBAL","GITHUB_ORGANIZATION","GITLAB_GROUP"
            break
        }


    }

    $v |
        Where-Object { $_ -like "$wordToComplete*" } |
        ForEach-Object { New-Object System.Management.Automation.CompletionResult $_, $_, 'ParameterValue', $_ }
}

$CB_map = @{
    "Artifacts_BucketOwnerAccess"=@("New-CBProject","Update-CBProject")
    "Artifacts_NamespaceType"=@("New-CBProject","Update-CBProject")
    "Artifacts_Packaging"=@("New-CBProject","Update-CBProject")
    "Artifacts_Type"=@("New-CBProject","Update-CBProject")
    "ArtifactsOverride_BucketOwnerAccess"=@("Start-CBBatch","Start-CBBuild")
    "ArtifactsOverride_NamespaceType"=@("Start-CBBatch","Start-CBBuild")
    "ArtifactsOverride_Packaging"=@("Start-CBBatch","Start-CBBuild")
    "ArtifactsOverride_Type"=@("Start-CBBatch","Start-CBBuild")
    "Auth_Type"=@("New-CBProject","Update-CBProject")
    "AuthType"=@("Import-CBSourceCredential")
    "BuildBatchConfig_BatchReportMode"=@("New-CBProject","Update-CBProject")
    "BuildBatchConfigOverride_BatchReportMode"=@("Start-CBBatch")
    "BuildType"=@("New-CBWebhook","Update-CBWebhook")
    "Cache_Type"=@("New-CBProject","Update-CBProject")
    "CacheOverride_Type"=@("Start-CBBatch","Start-CBBuild")
    "CloudWatchLogs_Status"=@("New-CBProject","Start-CBBatch","Start-CBBuild","Update-CBProject")
    "ComputeConfiguration_MachineType"=@("New-CBFleet","New-CBProject","Update-CBFleet","Update-CBProject")
    "ComputeType"=@("New-CBFleet","Update-CBFleet")
    "ComputeTypeOverride"=@("Start-CBBatch","Start-CBBuild")
    "Environment_ComputeType"=@("New-CBProject","Update-CBProject")
    "Environment_ImagePullCredentialsType"=@("New-CBProject","Update-CBProject")
    "Environment_Type"=@("New-CBProject","Update-CBProject")
    "EnvironmentType"=@("New-CBFleet","Update-CBFleet")
    "EnvironmentTypeOverride"=@("Start-CBBatch","Start-CBBuild")
    "ExportConfig_ExportConfigType"=@("New-CBReportGroup","Update-CBReportGroup")
    "Filter_Status"=@("Get-CBBatchIdList","Get-CBBatchIdListForProject","Get-CBReportList","Get-CBReportsForReportGroupList")
    "ImagePullCredentialsTypeOverride"=@("Start-CBBatch","Start-CBBuild")
    "OverflowBehavior"=@("New-CBFleet","Update-CBFleet")
    "ProjectVisibility"=@("Update-CBProjectVisibility")
    "ProxyConfiguration_DefaultBehavior"=@("New-CBFleet","Update-CBFleet")
    "RegistryCredential_CredentialProvider"=@("New-CBProject","Update-CBProject")
    "RegistryCredentialOverride_CredentialProvider"=@("Start-CBBatch","Start-CBBuild")
    "RetryType"=@("Redo-CBBatch")
    "S3Destination_Packaging"=@("New-CBReportGroup","Update-CBReportGroup")
    "S3Logs_BucketOwnerAccess"=@("New-CBProject","Start-CBBatch","Start-CBBuild","Update-CBProject")
    "S3Logs_Status"=@("New-CBProject","Start-CBBatch","Start-CBBuild","Update-CBProject")
    "ScalingConfiguration_ScalingType"=@("New-CBFleet","Update-CBFleet")
    "ScopeConfiguration_Scope"=@("New-CBWebhook")
    "ServerType"=@("Import-CBSourceCredential")
    "SortBy"=@("Get-CBCodeCoverage","Get-CBFleetList","Get-CBProjectList","Get-CBReportGroupList","Get-CBSharedProjectList","Get-CBSharedReportGroupList")
    "SortOrder"=@("Get-CBBatchIdList","Get-CBBatchIdListForProject","Get-CBBuildIdList","Get-CBBuildIdListForProject","Get-CBCodeCoverage","Get-CBFleetList","Get-CBProjectList","Get-CBReportGroupList","Get-CBReportList","Get-CBReportsForReportGroupList","Get-CBSharedProjectList","Get-CBSharedReportGroupList")
    "Source_Type"=@("New-CBProject","Update-CBProject")
    "SourceAuthOverride_Type"=@("Start-CBBatch","Start-CBBuild")
    "SourceTypeOverride"=@("Start-CBBatch","Start-CBBuild")
    "TrendField"=@("Get-CBReportGroupTrend")
    "Type"=@("New-CBReportGroup")
}

_awsArgumentCompleterRegistration $CB_Completers $CB_map

$CB_SelectCompleters = {
    param($commandName, $parameterName, $wordToComplete, $commandAst, $fakeBoundParameter)

    $cmdletType = Invoke-Expression "[Amazon.PowerShell.Cmdlets.CB.$($commandName.Replace('-', ''))Cmdlet]"
    if (-not $cmdletType) {
        return
    }
    $awsCmdletAttribute = $cmdletType.GetCustomAttributes([Amazon.PowerShell.Common.AWSCmdletAttribute], $false)
    if (-not $awsCmdletAttribute) {
        return
    }
    $type = $awsCmdletAttribute.SelectReturnType
    if (-not $type) {
        return
    }

    $splitSelect = $wordToComplete -Split '\.'
    $splitSelect | Select-Object -First ($splitSelect.Length - 1) | ForEach-Object {
        $propertyName = $_
        $properties = $type.GetProperties(('Instance', 'Public', 'DeclaredOnly')) | Where-Object { $_.Name -ieq $propertyName }
        if ($properties.Length -ne 1) {
            break
        }
        $type = $properties.PropertyType
        $prefix += "$($properties.Name)."

        $asEnumerableType = $type.GetInterface('System.Collections.Generic.IEnumerable`1')
        if ($asEnumerableType -and $type -ne [System.String]) {
            $type =  $asEnumerableType.GetGenericArguments()[0]
        }
    }

    $v = @( '*' )
    $properties = $type.GetProperties(('Instance', 'Public', 'DeclaredOnly')).Name | Sort-Object
    if ($properties) {
        $v += ($properties | ForEach-Object { $prefix + $_ })
    }
    $parameters = $cmdletType.GetProperties(('Instance', 'Public')) | Where-Object { $_.GetCustomAttributes([System.Management.Automation.ParameterAttribute], $true) } | Select-Object -ExpandProperty Name | Sort-Object
    if ($parameters) {
        $v += ($parameters | ForEach-Object { "^$_" })
    }

    $v |
        Where-Object { $_ -match "^$([System.Text.RegularExpressions.Regex]::Escape($wordToComplete)).*" } |
        ForEach-Object { New-Object System.Management.Automation.CompletionResult $_, $_, 'ParameterValue', $_ }
}

$CB_SelectMap = @{
    "Select"=@("Remove-CBBuildBatch",
               "Get-CBBatch",
               "Get-CBBuildBatch",
               "Get-CBCBFleetBatch",
               "Get-CBProjectBatch",
               "Get-CBReportGroupBatch",
               "Get-CBReportBatch",
               "New-CBFleet",
               "New-CBProject",
               "New-CBReportGroup",
               "New-CBWebhook",
               "Remove-CBBatch",
               "Remove-CBFleet",
               "Remove-CBProject",
               "Remove-CBReport",
               "Remove-CBReportGroup",
               "Remove-CBResourcePolicy",
               "Remove-CBSourceCredential",
               "Remove-CBWebhook",
               "Get-CBCodeCoverage",
               "Get-CBTestCase",
               "Get-CBReportGroupTrend",
               "Get-CBResourcePolicy",
               "Import-CBSourceCredential",
               "Reset-CBProjectCache",
               "Get-CBBatchIdList",
               "Get-CBBatchIdListForProject",
               "Get-CBBuildIdList",
               "Get-CBBuildIdListForProject",
               "Get-CBCuratedEnvironmentImageList",
               "Get-CBFleetList",
               "Get-CBProjectList",
               "Get-CBReportGroupList",
               "Get-CBReportList",
               "Get-CBReportsForReportGroupList",
               "Get-CBSharedProjectList",
               "Get-CBSharedReportGroupList",
               "Get-CBSourceCredentialList",
               "Write-CBResourcePolicy",
               "Redo-CBBuild",
               "Redo-CBBatch",
               "Start-CBBuild",
               "Start-CBBatch",
               "Stop-CBBuild",
               "Stop-CBBatch",
               "Update-CBFleet",
               "Update-CBProject",
               "Update-CBProjectVisibility",
               "Update-CBReportGroup",
               "Update-CBWebhook")
}

_awsArgumentCompleterRegistration $CB_SelectCompleters $CB_SelectMap


# SIG # Begin signature block
# MIIueAYJKoZIhvcNAQcCoIIuaTCCLmUCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCD+9Xe5OBMGsEql
# +K3BcGo7Su5zJy9yQzWZd6+c0B6NDqCCE+owggXAMIIEqKADAgECAhAP0bvKeWvX
# +N1MguEKmpYxMA0GCSqGSIb3DQEBCwUAMGwxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xKzApBgNV
# BAMTIkRpZ2lDZXJ0IEhpZ2ggQXNzdXJhbmNlIEVWIFJvb3QgQ0EwHhcNMjIwMTEz
# MDAwMDAwWhcNMzExMTA5MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMM
# RGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQD
# ExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwggIiMA0GCSqGSIb3DQEBAQUAA4IC
# DwAwggIKAoICAQC/5pBzaN675F1KPDAiMGkz7MKnJS7JIT3yithZwuEppz1Yq3aa
# za57G4QNxDAf8xukOBbrVsaXbR2rsnnyyhHS5F/WBTxSD1Ifxp4VpX6+n6lXFllV
# cq9ok3DCsrp1mWpzMpTREEQQLt+C8weE5nQ7bXHiLQwb7iDVySAdYyktzuxeTsiT
# +CFhmzTrBcZe7FsavOvJz82sNEBfsXpm7nfISKhmV1efVFiODCu3T6cw2Vbuyntd
# 463JT17lNecxy9qTXtyOj4DatpGYQJB5w3jHtrHEtWoYOAMQjdjUN6QuBX2I9YI+
# EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsDdV14Ztk6MUSaM0C/CNdaSaTC5qmgZ92k
# J7yhTzm1EVgX9yRcRo9k98FpiHaYdj1ZXUJ2h4mXaXpI8OCiEhtmmnTK3kse5w5j
# rubU75KSOp493ADkRSWJtppEGSt+wJS00mFt6zPZxd9LBADMfRyVw4/3IbKyEbe7
# f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hkpjPRiQfhvbfmQ6QYuKZ3AeEPlAwhHbJU
# KSWJbOUOUlFHdL4mrLZBdd56rF+NP8m800ERElvlEFDrMcXKchYiCd98THU/Y+wh
# X8QgUWtvsauGi0/C1kVfnSD8oR7FwI+isX4KJpn15GkvmB0t9dmpsh3lGwIDAQAB
# o4IBZjCCAWIwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wHwYDVR0jBBgwFoAUsT7DaQP4v0cB1JgmGggC72NkK8MwDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMH8GCCsGAQUFBwEBBHMwcTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEkGCCsGAQUFBzAC
# hj1odHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRIaWdoQXNzdXJh
# bmNlRVZSb290Q0EuY3J0MEsGA1UdHwREMEIwQKA+oDyGOmh0dHA6Ly9jcmwzLmRp
# Z2ljZXJ0LmNvbS9EaWdpQ2VydEhpZ2hBc3N1cmFuY2VFVlJvb3RDQS5jcmwwHAYD
# VR0gBBUwEzAHBgVngQwBAzAIBgZngQwBBAEwDQYJKoZIhvcNAQELBQADggEBAEHx
# qRH0DxNHecllao3A7pgEpMbjDPKisedfYk/ak1k2zfIe4R7sD+EbP5HU5A/C5pg0
# /xkPZigfT2IxpCrhKhO61z7H0ZL+q93fqpgzRh9Onr3g7QdG64AupP2uU7SkwaT1
# IY1rzAGt9Rnu15ClMlIr28xzDxj4+87eg3Gn77tRWwR2L62t0+od/P1Tk+WMieNg
# GbngLyOOLFxJy34riDkruQZhiPOuAnZ2dMFkkbiJUZflhX0901emWG4f7vtpYeJa
# 3Cgh6GO6Ps9W7Zrk9wXqyvPsEt84zdp7PiuTUy9cUQBY3pBIowrHC/Q7bVUx8ALM
# R3eWUaNetbxcyEMRoacwggawMIIEmKADAgECAhAIrUCyYNKcTJ9ezam9k67ZMA0G
# CSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0zNjA0MjgyMzU5NTla
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDVtC9C
# 0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0JAfhS0/TeEP0F9ce
# 2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJrQ5qZ8sU7H/Lvy0da
# E6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhFLqGfLOEYwhrMxe6T
# SXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+FLEikVoQ11vkunKoA
# FdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh3K3kGKDYwSNHR7Oh
# D26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJwZPt4bRc4G/rJvmM
# 1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQayg9Rc9hUZTO1i4F4z
# 8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbIYViY9XwCFjyDKK05
# huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchApQfDVxW0mdmgRQRNY
# mtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRroOBl8ZhzNeDhFMJlP
# /2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IBWTCCAVUwEgYDVR0T
# AQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHwYD
# VR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNV
# HR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRU
# cnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAEDMAgGBmeBDAEEATAN
# BgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql+Eg08yy25nRm95Ry
# sQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFFUP2cvbaF4HZ+N3HL
# IvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1hmYFW9snjdufE5Btf
# Q/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3RywYFzzDaju4ImhvTnh
# OE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5UbdldAhQfQDN8A+KVssIh
# dXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw8MzK7/0pNVwfiThV
# 9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnPLqR0kq3bPKSchh/j
# wVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatEQOON8BUozu3xGFYH
# Ki8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bnKD+sEq6lLyJsQfmC
# XBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQjiWQ1tygVQK+pKHJ6l
# /aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbqyK+p/pQd52MbOoZW
# eE4wggduMIIFVqADAgECAhAOG4Qdo7UmBpSv170eUaMrMA0GCSqGSIb3DQEBCwUA
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwHhcNMjQwODAyMDAwMDAwWhcNMjUwODAxMjM1OTU5WjCB9jET
# MBEGCysGAQQBgjc8AgEDEwJVUzEZMBcGCysGAQQBgjc8AgECEwhEZWxhd2FyZTEd
# MBsGA1UEDwwUUHJpdmF0ZSBPcmdhbml6YXRpb24xEDAOBgNVBAUTBzQxNTI5NTQx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdTZWF0
# dGxlMSIwIAYDVQQKExlBbWF6b24gV2ViIFNlcnZpY2VzLCBJbmMuMRcwFQYDVQQL
# Ew5TREtzIGFuZCBUb29sczEiMCAGA1UEAxMZQW1hem9uIFdlYiBTZXJ2aWNlcywg
# SW5jLjCCAaIwDQYJKoZIhvcNAQEBBQADggGPADCCAYoCggGBAJn5K00vaam9Tsax
# bhWuOwBweiOIeGUkpi0F5SYcPijYzpnd7vS0G3WYbFuSTGKipaRe37VDHdNa9Y1F
# faRSBrKmeNytBzNsnIUtiKl5OWuQkbaNcH/8XHwPOf6szaqz6wnnkhj0Bv0zA+Ih
# IVAyPg7T8bqJRkGfOf5ugIH06fPVFj1KWuugiXNs1/M4/FLyBLsSJZbfvID+TVWO
# 2YjFBLDDVrOB7rw22KJYl4w1q+wfUUm05uRX5I+uLiRaT88l1MZHLwHg1nuL0Vm9
# t41X2xTOn4QeqxIXo1BbcVfiyjPogrU9xHUs2B1JyEVZWjv4VUwfOW0X3er1Ukwn
# Kqxsjg/2ikAT4oRjFgWnLsU0VoRDkkShhfVtC5pSB6v/v0gzgReQNqElCVcKwOHj
# fiTzbRRWHFwYzNwEqnSAhC+qB/zYXWg9KBF1DtVcWVLaHMXuLn0plnHWA/AoPZcl
# hc7HjClr15RcrHl6pcclBHtRBtJkX7jLlC7cAWkob+4Wp/QyVwIDAQABo4ICAjCC
# Af4wHwYDVR0jBBgwFoAUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHQYDVR0OBBYEFAa4
# CewhP0BkYi71XHKKI9o8p1BMMD0GA1UdIAQ2MDQwMgYFZ4EMAQMwKTAnBggrBgEF
# BQcCARYbaHR0cDovL3d3dy5kaWdpY2VydC5jb20vQ1BTMA4GA1UdDwEB/wQEAwIH
# gDATBgNVHSUEDDAKBggrBgEFBQcDAzCBtQYDVR0fBIGtMIGqMFOgUaBPhk1odHRw
# Oi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmlu
# Z1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNybDBToFGgT4ZNaHR0cDovL2NybDQuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hB
# Mzg0MjAyMUNBMS5jcmwwgZQGCCsGAQUFBwEBBIGHMIGEMCQGCCsGAQUFBzABhhho
# dHRwOi8vb2NzcC5kaWdpY2VydC5jb20wXAYIKwYBBQUHMAKGUGh0dHA6Ly9jYWNl
# cnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNB
# NDA5NlNIQTM4NDIwMjFDQTEuY3J0MAkGA1UdEwQCMAAwDQYJKoZIhvcNAQELBQAD
# ggIBAISiRgUmPdqs8OdhLLJ8Blj9EmNwt3MNQszq45nw9ApvgRRXBYFTA/5JFJQv
# 4k3qqAeOlt0vbGnzDHVzWq7JEGJZrUn7qfkmj4jflPJ1c6iOCUZFb8+x+45K/9ks
# o4yS4Y3M2gCDKJMrKmgyhm/qZL2oXbViT3XB4iVYr/+eHLf+146UWYrYtR5clim9
# FM1tkXV9n4gk+h5FRgSDXoqSiwoyM60ziNutQAKsNAHjnazBWRluKwhtpVMRuHu8
# 1SbIeTJ/xz0F2P90vmMu2SBhtsnO4QL3uMznLJ6qvAQVfny/T2bMSSPROHIXSDvA
# qCThkA49Gi/5NXKmMs8ukZzLOkTEx8V5uKxEf4gI9q17oLYG8oX5e+FlldVpxRRf
# kru1RtPu4MCAzvLYTdLgk9Rovglztgic8gQNSQO/pjHX7zAZ5Ys+M4japyzrzhwK
# yCwfnKWAv8b+5pqSsJh4bdoXQtGBP/QOiKjD3+ip/D36hw4ZKYoVu5XJu+rnY+or
# 8dXYA9uaZYrVGLH16W8bidzPT3wCcBOWcod4WHQW+Rk2AoRLAj2Nj+TxwlDIDQkA
# SD/n7Sm0FLFzjBmPD5YfFu58jefNV2HW3aBFuM+1e0VyjuRPz+dmP0vG8HVL8ste
# NxL0ev/CF619Ef4FsUgUwTSV0IvDtgYkxlbtwuzHqYSWUFo4MYIZ5DCCGeACAQEw
# fTBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNV
# BAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgQ29kZSBTaWduaW5nIFJTQTQwOTYgU0hB
# Mzg0IDIwMjEgQ0ExAhAOG4Qdo7UmBpSv170eUaMrMA0GCWCGSAFlAwQCAQUAoHww
# EAYKKwYBBAGCNwIBDDECMAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEILer0JbG
# b+cArszU6zWZ8llV5Siob/9qoktpm9TqXe8DMA0GCSqGSIb3DQEBAQUABIIBgCzq
# qF5pXVJQ5zA1N9UQjTU0e7+Uc5RmauIjUDacdHsPIcIfClYFntDjd2UV9SK2RJE8
# hcC3pq8tBoO3Mh1y1bgV7HCrrPI6Dxeeom87Amg3O9mjin7gu9J1CAdNaiUCjtcC
# 8g9/4zU2gP8trtns5GVZ3kI/dfPwpPJYXKBajr8XUUCKLLhvMjKvasPXaBB1KUbk
# lDPch+9OTVZ7mWxnpUAatA7zp0tMCSFFe1zU2M02A0+IiQPbWkcmcbEAKY9ezMH9
# QOO6QguUOSvDHOed+u2+7dswgZhbnjgioM9Atb64rYxg5z/lQpM5OK2Hmm+iWkzP
# cK8+7mPB48/PP5MnhQ2KuYMPmdPZ8/aRb88na2+y8wAEeia7W7rnl9aYVfeWHi8I
# 1Ztv38dSyUQE28uTVJxw91v/oyi/ctFcoZLvBk4G8xgPV2FRlJrJR2DaP7AiywN/
# YFiFPB+hGXSXINT1M3KgdoLI0UNGXhO4hpknQvN1MEaplQ6Y/Lcfaf5yhlWiFaGC
# Fzowghc2BgorBgEEAYI3AwMBMYIXJjCCFyIGCSqGSIb3DQEHAqCCFxMwghcPAgED
# MQ8wDQYJYIZIAWUDBAIBBQAweAYLKoZIhvcNAQkQAQSgaQRnMGUCAQEGCWCGSAGG
# /WwHATAxMA0GCWCGSAFlAwQCAQUABCAG5vpLeCtK6GHY7+dI7CNLMrAxCVCM/6Xm
# 88b9F7obcwIRAIcBxFUQgHyL7/ZxoL4HGyUYDzIwMjUwMjA2MjE1MjI1WqCCEwMw
# gga8MIIEpKADAgECAhALrma8Wrp/lYfG+ekE4zMEMA0GCSqGSIb3DQEBCwUAMGMx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMy
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcg
# Q0EwHhcNMjQwOTI2MDAwMDAwWhcNMzUxMTI1MjM1OTU5WjBCMQswCQYDVQQGEwJV
# UzERMA8GA1UEChMIRGlnaUNlcnQxIDAeBgNVBAMTF0RpZ2lDZXJ0IFRpbWVzdGFt
# cCAyMDI0MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAvmpzn/aVIauW
# MLpbbeZZo7Xo/ZEfGMSIO2qZ46XB/QowIEMSvgjEdEZ3v4vrrTHleW1JWGErrjOL
# 0J4L0HqVR1czSzvUQ5xF7z4IQmn7dHY7yijvoQ7ujm0u6yXF2v1CrzZopykD07/9
# fpAT4BxpT9vJoJqAsP8YuhRvflJ9YeHjes4fduksTHulntq9WelRWY++TFPxzZrb
# ILRYynyEy7rS1lHQKFpXvo2GePfsMRhNf1F41nyEg5h7iOXv+vjX0K8RhUisfqw3
# TTLHj1uhS66YX2LZPxS4oaf33rp9HlfqSBePejlYeEdU740GKQM7SaVSH3TbBL8R
# 6HwX9QVpGnXPlKdE4fBIn5BBFnV+KwPxRNUNK6lYk2y1WSKour4hJN0SMkoaNV8h
# yyADiX1xuTxKaXN12HgR+8WulU2d6zhzXomJ2PleI9V2yfmfXSPGYanGgxzqI+Sh
# oOGLomMd3mJt92nm7Mheng/TBeSA2z4I78JpwGpTRHiT7yHqBiV2ngUIyCtd0pZ8
# zg3S7bk4QC4RrcnKJ3FbjyPAGogmoiZ33c1HG93Vp6lJ415ERcC7bFQMRbxqrMVA
# Niav1k425zYyFMyLNyE1QulQSgDpW9rtvVcIH7WvG9sqYup9j8z9J1XqbBZPJ5XL
# ln8mS8wWmdDLnBHXgYly/p1DhoQo5fkCAwEAAaOCAYswggGHMA4GA1UdDwEB/wQE
# AwIHgDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMCAGA1Ud
# IAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATAfBgNVHSMEGDAWgBS6FtltTYUv
# cyl2mi91jGogj57IbzAdBgNVHQ4EFgQUn1csA3cOKBWQZqVjXu5Pkh92oFswWgYD
# VR0fBFMwUTBPoE2gS4ZJaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNybDCBkAYIKwYB
# BQUHAQEEgYMwgYAwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNv
# bTBYBggrBgEFBQcwAoZMaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lD
# ZXJ0VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNydDANBgkq
# hkiG9w0BAQsFAAOCAgEAPa0eH3aZW+M4hBJH2UOR9hHbm04IHdEoT8/T3HuBSyZe
# q3jSi5GXeWP7xCKhVireKCnCs+8GZl2uVYFvQe+pPTScVJeCZSsMo1JCoZN2mMew
# /L4tpqVNbSpWO9QGFwfMEy60HofN6V51sMLMXNTLfhVqs+e8haupWiArSozyAmGH
# /6oMQAh078qRh6wvJNU6gnh5OruCP1QUAvVSu4kqVOcJVozZR5RRb/zPd++PGE3q
# F1P3xWvYViUJLsxtvge/mzA75oBfFZSbdakHJe2BVDGIGVNVjOp8sNt70+kEoMF+
# T6tptMUNlehSR7vM+C13v9+9ZOUKzfRUAYSyyEmYtsnpltD/GWX8eM70ls1V6QG/
# ZOB6b6Yum1HvIiulqJ1Elesj5TMHq8CWT/xrW7twipXTJ5/i5pkU5E16RSBAdOp1
# 2aw8IQhhA/vEbFkEiF2abhuFixUDobZaA0VhqAsMHOmaT3XThZDNi5U2zHKhUs5u
# HHdG6BoQau75KiNbh0c+hatSF+02kULkftARjsyEpHKsF7u5zKRbt5oK5YGwFvgc
# 4pEVUNytmB3BpIiowOIIuDgP5M9WArHYSAR16gc0dP2XdkMEP5eBsX7bf/MGN4K3
# HP50v/01ZHo/Z5lGLvNwQ7XHBx1yomzLP8lx4Q1zZKDyHcp4VQJLu2kWTsKsOqQw
# ggauMIIElqADAgECAhAHNje3JFR82Ees/ShmKl5bMA0GCSqGSIb3DQEBCwUAMGIx
# CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3
# dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBH
# NDAeFw0yMjAzMjMwMDAwMDBaFw0zNzAzMjIyMzU5NTlaMGMxCzAJBgNVBAYTAlVT
# MRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNlcnQgVHJ1
# c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0EwggIiMA0GCSqG
# SIb3DQEBAQUAA4ICDwAwggIKAoICAQDGhjUGSbPBPXJJUVXHJQPE8pE3qZdRodbS
# g9GeTKJtoLDMg/la9hGhRBVCX6SI82j6ffOciQt/nR+eDzMfUBMLJnOWbfhXqAJ9
# /UO0hNoR8XOxs+4rgISKIhjf69o9xBd/qxkrPkLcZ47qUT3w1lbU5ygt69OxtXXn
# HwZljZQp09nsad/ZkIdGAHvbREGJ3HxqV3rwN3mfXazL6IRktFLydkf3YYMZ3V+0
# VAshaG43IbtArF+y3kp9zvU5EmfvDqVjbOSmxR3NNg1c1eYbqMFkdECnwHLFuk4f
# sbVYTXn+149zk6wsOeKlSNbwsDETqVcplicu9Yemj052FVUmcJgmf6AaRyBD40Nj
# gHt1biclkJg6OBGz9vae5jtb7IHeIhTZgirHkr+g3uM+onP65x9abJTyUpURK1h0
# QCirc0PO30qhHGs4xSnzyqqWc0Jon7ZGs506o9UD4L/wojzKQtwYSH8UNM/STKvv
# mz3+DrhkKvp1KCRB7UK/BZxmSVJQ9FHzNklNiyDSLFc1eSuo80VgvCONWPfcYd6T
# /jnA+bIwpUzX6ZhKWD7TA4j+s4/TXkt2ElGTyYwMO1uKIqjBJgj5FBASA31fI7tk
# 42PgpuE+9sJ0sj8eCXbsq11GdeJgo1gJASgADoRU7s7pXcheMBK9Rp6103a50g5r
# mQzSM7TNsQIDAQABo4IBXTCCAVkwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4E
# FgQUuhbZbU2FL3MpdpovdYxqII+eyG8wHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMIMHcG
# CCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQu
# Y29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGln
# aUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8v
# Y3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAgBgNV
# HSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggIB
# AH1ZjsCTtm+YqUQiAX5m1tghQuGwGC4QTRPPMFPOvxj7x1Bd4ksp+3CKDaopafxp
# wc8dB+k+YMjYC+VcW9dth/qEICU0MWfNthKWb8RQTGIdDAiCqBa9qVbPFXONASIl
# zpVpP0d3+3J0FNf/q0+KLHqrhc1DX+1gtqpPkWaeLJ7giqzl/Yy8ZCaHbJK9nXzQ
# cAp876i8dU+6WvepELJd6f8oVInw1YpxdmXazPByoyP6wCeCRK6ZJxurJB4mwbfe
# Kuv2nrF5mYGjVoarCkXJ38SNoOeY+/umnXKvxMfBwWpx2cYTgAnEtp/Nh4cku0+j
# Sbl3ZpHxcpzpSwJSpzd+k1OsOx0ISQ+UzTl63f8lY5knLD0/a6fxZsNBzU+2QJsh
# IUDQtxMkzdwdeDrknq3lNHGS1yZr5Dhzq6YBT70/O3itTK37xJV77QpfMzmHQXh6
# OOmc4d0j/R0o08f56PGYX/sr2H7yRp11LB4nLCbbbxV7HhmLNriT1ObyF5lZynDw
# N7+YAN8gFk8n+2BnFqFmut1VwDophrCYoCvtlUG3OtUVmDG0YgkPCr2B2RP+v6TR
# 81fZvAT6gt4y3wSJ8ADNXcL50CN/AAvkdgIm2fBldkKmKYcJRyvmfxqkhQ/8mJb2
# VVQrH4D6wPIOK+XW+6kvRBVK5xMOHds3OBqhK/bt1nz8MIIFjTCCBHWgAwIBAgIQ
# DpsYjvnQLefv21DiCEAYWjANBgkqhkiG9w0BAQwFADBlMQswCQYDVQQGEwJVUzEV
# MBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29t
# MSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMjIwODAx
# MDAwMDAwWhcNMzExMTA5MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMM
# RGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQD
# ExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwggIiMA0GCSqGSIb3DQEBAQUAA4IC
# DwAwggIKAoICAQC/5pBzaN675F1KPDAiMGkz7MKnJS7JIT3yithZwuEppz1Yq3aa
# za57G4QNxDAf8xukOBbrVsaXbR2rsnnyyhHS5F/WBTxSD1Ifxp4VpX6+n6lXFllV
# cq9ok3DCsrp1mWpzMpTREEQQLt+C8weE5nQ7bXHiLQwb7iDVySAdYyktzuxeTsiT
# +CFhmzTrBcZe7FsavOvJz82sNEBfsXpm7nfISKhmV1efVFiODCu3T6cw2Vbuyntd
# 463JT17lNecxy9qTXtyOj4DatpGYQJB5w3jHtrHEtWoYOAMQjdjUN6QuBX2I9YI+
# EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsDdV14Ztk6MUSaM0C/CNdaSaTC5qmgZ92k
# J7yhTzm1EVgX9yRcRo9k98FpiHaYdj1ZXUJ2h4mXaXpI8OCiEhtmmnTK3kse5w5j
# rubU75KSOp493ADkRSWJtppEGSt+wJS00mFt6zPZxd9LBADMfRyVw4/3IbKyEbe7
# f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hkpjPRiQfhvbfmQ6QYuKZ3AeEPlAwhHbJU
# KSWJbOUOUlFHdL4mrLZBdd56rF+NP8m800ERElvlEFDrMcXKchYiCd98THU/Y+wh
# X8QgUWtvsauGi0/C1kVfnSD8oR7FwI+isX4KJpn15GkvmB0t9dmpsh3lGwIDAQAB
# o4IBOjCCATYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wHwYDVR0jBBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDgYDVR0P
# AQH/BAQDAgGGMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29j
# c3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MEUGA1UdHwQ+MDww
# OqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RFJvb3RDQS5jcmwwEQYDVR0gBAowCDAGBgRVHSAAMA0GCSqGSIb3DQEBDAUAA4IB
# AQBwoL9DXFXnOF+go3QbPbYW1/e/Vwe9mqyhhyzshV6pGrsi+IcaaVQi7aSId229
# GhT0E0p6Ly23OO/0/4C5+KH38nLeJLxSA8hO0Cre+i1Wz/n096wwepqLsl7Uz9FD
# RJtDIeuWcqFItJnLnU+nBgMTdydE1Od/6Fmo8L8vC6bp8jQ87PcDx4eo0kxAGTVG
# amlUsLihVo7spNU96LHc/RzY9HdaXFSMb++hUD38dglohJ9vytsgjTVgHAIDyyCw
# rFigDkBjxZgiwbJZ9VVrzyerbHbObyMt9H5xaiNrIv8SuFQtJ37YOtnwtoeW/VvR
# XKwYw02fc7cBqZ9Xql4o4rmUMYIDdjCCA3ICAQEwdzBjMQswCQYDVQQGEwJVUzEX
# MBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0
# ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5nIENBAhALrma8Wrp/lYfG
# +ekE4zMEMA0GCWCGSAFlAwQCAQUAoIHRMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0B
# CRABBDAcBgkqhkiG9w0BCQUxDxcNMjUwMjA2MjE1MjI1WjArBgsqhkiG9w0BCRAC
# DDEcMBowGDAWBBTb04XuYtvSPnvk9nFIUIck1YZbRTAvBgkqhkiG9w0BCQQxIgQg
# BQ2/vtddcQESbqXswNaS8tLd/FEGzK5vYJLk0+IlIt8wNwYLKoZIhvcNAQkQAi8x
# KDAmMCQwIgQgdnafqPJjLx9DCzojMK7WVnX+13PbBdZluQWTmEOPmtswDQYJKoZI
# hvcNAQEBBQAEggIAIUPrJ0o8xImsdukcoMajkieXCxQ+xxFWidERWlQMMgvg+ivb
# oZYXgJZpaxRRILl19XWgL+0TU20bfIubtp4omMRlp8TJV9F8ExPObN2PPqjY41cs
# yLu6x+fu5GUVe98l0hcOIniCMbqGIMPUDUlujN+06Etotdpm3RhNfEFxJxshv54u
# 4/NqXx9j+LktjQbUqzZU/H2jsc+p41zDHjrIT8uJB7zmy/1y5tq+4RqLnAC2GEi8
# EaYnahn+4aBt9PsZWZbNtpbSxMQAT7DYcmIJnqn4bhrGJFUa8EIEs8SNTW9pjjsV
# tCvIYyet31N8/jxZFTer3YjkCeRmRGXbK1i3D9D2la7bCWoFtht6iNY/090Aalo+
# BuOoTmvRUJs0gIqS7sx8v1/BoW9SMt0QG9/3AawsN+U8J957YqxEnjXkbBsyqzPF
# gbVwlXlan+uQDOrrZOv0xtNop2i960Hzke7phN7vxpPTZkkmq3ve6QznPTMXC4Sc
# 1PhLm/8fl/D4hVo/3VVg3UE62ZgZT5NxOvJ85eQZM3bXUVSOwMn40lTWYBRG93DO
# QDRUo0GNlnIymnIQXzC59lb/wMXnIs9MPML16FKmGqZsfkwITTUHxOLELQAY5GJb
# yC3ovcURmPnOdWpYYBk3fq8q21fzb5YZ2VwsFUFX6n2kpixN5WbLt0d9U+g=
# SIG # End signature block
