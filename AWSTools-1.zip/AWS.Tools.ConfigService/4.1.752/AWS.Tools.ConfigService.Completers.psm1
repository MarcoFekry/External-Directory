# Auto-generated argument completers for parameters of SDK ConstantClass-derived type used in cmdlets.
# Do not modify this file; it may be overwritten during version upgrades.

$psMajorVersion = $PSVersionTable.PSVersion.Major
if ($psMajorVersion -eq 2) 
{ 
	Write-Verbose "Dynamic argument completion not supported in PowerShell version 2; skipping load."
	return 
}

# PowerShell's native Register-ArgumentCompleter cmdlet is available on v5.0 or higher. For lower
# version, we can use the version in the TabExpansion++ module if installed.
$registrationCmdletAvailable = ($psMajorVersion -ge 5) -Or !((Get-Command Register-ArgumentCompleter -ea Ignore) -eq $null)

# internal function to perform the registration using either cmdlet or manipulation
# of the options table
function _awsArgumentCompleterRegistration()
{
    param
    (
        [scriptblock]$scriptBlock,
        [hashtable]$param2CmdletsMap
    )

    if ($registrationCmdletAvailable)
    {
        foreach ($paramName in $param2CmdletsMap.Keys)
        {
             $args = @{
                "ScriptBlock" = $scriptBlock
                "Parameter" = $paramName
            }

            $cmdletNames = $param2CmdletsMap[$paramName]
            if ($cmdletNames -And $cmdletNames.Length -gt 0)
            {
                $args["Command"] = $cmdletNames
            }

            Register-ArgumentCompleter @args
        }
    }
    else
    {
        if (-not $global:options) { $global:options = @{ CustomArgumentCompleters = @{ }; NativeArgumentCompleters = @{ } } }

        foreach ($paramName in $param2CmdletsMap.Keys)
        {
            $cmdletNames = $param2CmdletsMap[$paramName]

            if ($cmdletNames -And $cmdletNames.Length -gt 0)
            {
                foreach ($cn in $cmdletNames)
                {
                    $fqn =  [string]::Concat($cn, ":", $paramName)
                    $global:options['CustomArgumentCompleters'][$fqn] = $scriptBlock
                }
            }
            else
            {
                $global:options['CustomArgumentCompleters'][$paramName] = $scriptBlock
            }
        }

        $function:tabexpansion2 = $function:tabexpansion2 -replace 'End\r\n{', 'End { if ($null -ne $options) { $options += $global:options} else {$options = $global:options}'
    }
}

# To allow for same-name parameters of different ConstantClass-derived types 
# each completer function checks on command name concatenated with parameter name.
# Additionally, the standard code pattern for completers is to pipe through 
# sort-object after filtering against $wordToComplete but we omit this as our members 
# are already sorted.

# Argument completions for service AWS Config


$CFG_Completers = {
    param($commandName, $parameterName, $wordToComplete, $commandAst, $fakeBoundParameter)

    switch ($("$commandName/$parameterName"))
    {
        # Amazon.ConfigService.AggregateConformancePackComplianceSummaryGroupKey
        "Get-CFGAggregateConformancePackComplianceSummary/GroupByKey"
        {
            $v = "ACCOUNT_ID","AWS_REGION"
            break
        }

        # Amazon.ConfigService.AggregatorFilterType
        {
            ($_ -eq "Write-CFGConfigurationAggregator/ResourceType_Type") -Or
            ($_ -eq "Write-CFGConfigurationAggregator/ServicePrincipal_Type")
        }
        {
            $v = "INCLUDE"
            break
        }

        # Amazon.ConfigService.ChronologicalOrder
        "Get-CFGResourceConfigHistory/ChronologicalOrder"
        {
            $v = "Forward","Reverse"
            break
        }

        # Amazon.ConfigService.ComplianceType
        {
            ($_ -eq "Get-CFGAggregateComplianceDetailsByConfigRule/ComplianceType") -Or
            ($_ -eq "Write-CFGExternalEvaluation/ExternalEvaluation_ComplianceType") -Or
            ($_ -eq "Get-CFGAggregateComplianceByConfigRuleList/Filters_ComplianceType")
        }
        {
            $v = "COMPLIANT","INSUFFICIENT_DATA","NON_COMPLIANT","NOT_APPLICABLE"
            break
        }

        # Amazon.ConfigService.ConfigRuleComplianceSummaryGroupKey
        "Get-CFGAggregateConfigRuleComplianceSummary/GroupByKey"
        {
            $v = "ACCOUNT_ID","AWS_REGION"
            break
        }

        # Amazon.ConfigService.ConfigRuleState
        "Write-CFGConfigRule/ConfigRule_ConfigRuleState"
        {
            $v = "ACTIVE","DELETING","DELETING_RESULTS","EVALUATING"
            break
        }

        # Amazon.ConfigService.ConformancePackComplianceType
        {
            ($_ -eq "Get-CFGAggregateComplianceByConformancePack/Filters_ComplianceType") -Or
            ($_ -eq "Get-CFGConformancePackCompliance/Filters_ComplianceType") -Or
            ($_ -eq "Get-CFGConformancePackComplianceDetail/Filters_ComplianceType")
        }
        {
            $v = "COMPLIANT","INSUFFICIENT_DATA","NON_COMPLIANT"
            break
        }

        # Amazon.ConfigService.EvaluationMode
        {
            ($_ -eq "Start-CFGResourceEvaluation/EvaluationMode") -Or
            ($_ -eq "Get-CFGConfigRule/Filters_EvaluationMode") -Or
            ($_ -eq "Get-CFGResourceEvaluationList/Filters_EvaluationMode")
        }
        {
            $v = "DETECTIVE","PROACTIVE"
            break
        }

        # Amazon.ConfigService.MaximumExecutionFrequency
        {
            ($_ -eq "Write-CFGConfigRule/ConfigRule_MaximumExecutionFrequency") -Or
            ($_ -eq "Write-CFGDeliveryChannel/ConfigSnapshotDeliveryProperties_DeliveryFrequency") -Or
            ($_ -eq "Write-CFGOrganizationConfigRule/OrganizationCustomPolicyRuleMetadata_MaximumExecutionFrequency") -Or
            ($_ -eq "Write-CFGOrganizationConfigRule/OrganizationCustomRuleMetadata_MaximumExecutionFrequency") -Or
            ($_ -eq "Write-CFGOrganizationConfigRule/OrganizationManagedRuleMetadata_MaximumExecutionFrequency")
        }
        {
            $v = "One_Hour","Six_Hours","Three_Hours","Twelve_Hours","TwentyFour_Hours"
            break
        }

        # Amazon.ConfigService.MemberAccountRuleStatus
        "Get-CFGOrganizationConfigRuleDetailedStatus/Filters_MemberAccountRuleStatus"
        {
            $v = "CREATE_FAILED","CREATE_IN_PROGRESS","CREATE_SUCCESSFUL","DELETE_FAILED","DELETE_IN_PROGRESS","DELETE_SUCCESSFUL","UPDATE_FAILED","UPDATE_IN_PROGRESS","UPDATE_SUCCESSFUL"
            break
        }

        # Amazon.ConfigService.OrganizationResourceDetailedStatus
        "Get-CFGOrganizationConformancePackDetailedStatus/Filters_Status"
        {
            $v = "CREATE_FAILED","CREATE_IN_PROGRESS","CREATE_SUCCESSFUL","DELETE_FAILED","DELETE_IN_PROGRESS","DELETE_SUCCESSFUL","UPDATE_FAILED","UPDATE_IN_PROGRESS","UPDATE_SUCCESSFUL"
            break
        }

        # Amazon.ConfigService.Owner
        "Write-CFGConfigRule/Source_Owner"
        {
            $v = "AWS","CUSTOM_LAMBDA","CUSTOM_POLICY"
            break
        }

        # Amazon.ConfigService.RecordingFrequency
        "Write-CFGConfigurationRecorder/RecordingMode_RecordingFrequency"
        {
            $v = "CONTINUOUS","DAILY"
            break
        }

        # Amazon.ConfigService.RecordingScope
        "Write-CFGConfigurationRecorder/ConfigurationRecorder_RecordingScope"
        {
            $v = "INTERNAL","PAID"
            break
        }

        # Amazon.ConfigService.RecordingStrategyType
        "Write-CFGConfigurationRecorder/RecordingStrategy_UseOnly"
        {
            $v = "ALL_SUPPORTED_RESOURCE_TYPES","EXCLUSION_BY_RESOURCE_TYPES","INCLUSION_BY_RESOURCE_TYPES"
            break
        }

        # Amazon.ConfigService.ResourceConfigurationSchemaType
        "Start-CFGResourceEvaluation/ResourceDetails_ResourceConfigurationSchemaType"
        {
            $v = "CFN_RESOURCE_SCHEMA"
            break
        }

        # Amazon.ConfigService.ResourceCountGroupKey
        "Get-CFGAggregateDiscoveredResourceCount/GroupByKey"
        {
            $v = "ACCOUNT_ID","AWS_REGION","RESOURCE_TYPE"
            break
        }

        # Amazon.ConfigService.ResourceType
        {
            ($_ -eq "Get-CFGAggregateDiscoveredResourceCount/Filters_ResourceType") -Or
            ($_ -eq "Get-CFGAggregateResourceConfig/ResourceIdentifier_ResourceType") -Or
            ($_ -eq "Get-CFGAggregateDiscoveredResourceList/ResourceType") -Or
            ($_ -eq "Get-CFGDiscoveredResource/ResourceType") -Or
            ($_ -eq "Get-CFGResourceConfigHistory/ResourceType")
        }
        {
            $v = "AWS::AccessAnalyzer::Analyzer","AWS::ACM::Certificate","AWS::ACMPCA::CertificateAuthority","AWS::ACMPCA::CertificateAuthorityActivation","AWS::AmazonMQ::Broker","AWS::Amplify::App","AWS::Amplify::Branch","AWS::ApiGateway::RestApi","AWS::ApiGateway::Stage","AWS::ApiGatewayV2::Api","AWS::ApiGatewayV2::Stage","AWS::AppConfig::Application","AWS::AppConfig::ConfigurationProfile","AWS::AppConfig::DeploymentStrategy","AWS::AppConfig::Environment","AWS::AppConfig::HostedConfigurationVersion","AWS::AppFlow::Flow","AWS::AppIntegrations::EventIntegration","AWS::AppMesh::GatewayRoute","AWS::AppMesh::Mesh","AWS::AppMesh::Route","AWS::AppMesh::VirtualGateway","AWS::AppMesh::VirtualNode","AWS::AppMesh::VirtualRouter","AWS::AppMesh::VirtualService","AWS::AppRunner::Service","AWS::AppRunner::VpcConnector","AWS::AppStream::Application","AWS::AppStream::DirectoryConfig","AWS::AppStream::Fleet","AWS::AppStream::Stack","AWS::AppSync::GraphQLApi","AWS::APS::RuleGroupsNamespace","AWS::Athena::DataCatalog","AWS::Athena::PreparedStatement","AWS::Athena::WorkGroup","AWS::AuditManager::Assessment","AWS::AutoScaling::AutoScalingGroup","AWS::AutoScaling::LaunchConfiguration","AWS::AutoScaling::ScalingPolicy","AWS::AutoScaling::ScheduledAction","AWS::AutoScaling::WarmPool","AWS::Backup::BackupPlan","AWS::Backup::BackupSelection","AWS::Backup::BackupVault","AWS::Backup::RecoveryPoint","AWS::Backup::ReportPlan","AWS::Batch::ComputeEnvironment","AWS::Batch::JobQueue","AWS::Batch::SchedulingPolicy","AWS::Budgets::BudgetsAction","AWS::Cassandra::Keyspace","AWS::Cloud9::EnvironmentEC2","AWS::CloudFormation::Stack","AWS::CloudFront::Distribution","AWS::CloudFront::StreamingDistribution","AWS::CloudTrail::Trail","AWS::CloudWatch::Alarm","AWS::CloudWatch::MetricStream","AWS::CodeArtifact::Repository","AWS::CodeBuild::Project","AWS::CodeBuild::ReportGroup","AWS::CodeDeploy::Application","AWS::CodeDeploy::DeploymentConfig","AWS::CodeDeploy::DeploymentGroup","AWS::CodeGuruProfiler::ProfilingGroup","AWS::CodeGuruReviewer::RepositoryAssociation","AWS::CodePipeline::Pipeline","AWS::Cognito::UserPool","AWS::Cognito::UserPoolClient","AWS::Cognito::UserPoolGroup","AWS::Config::ConformancePackCompliance","AWS::Config::ResourceCompliance","AWS::Connect::Instance","AWS::Connect::PhoneNumber","AWS::Connect::QuickConnect","AWS::CustomerProfiles::Domain","AWS::CustomerProfiles::ObjectType","AWS::DataSync::LocationEFS","AWS::DataSync::LocationFSxLustre","AWS::DataSync::LocationFSxWindows","AWS::DataSync::LocationHDFS","AWS::DataSync::LocationNFS","AWS::DataSync::LocationObjectStorage","AWS::DataSync::LocationS3","AWS::DataSync::LocationSMB","AWS::DataSync::Task","AWS::Detective::Graph","AWS::DeviceFarm::InstanceProfile","AWS::DeviceFarm::Project","AWS::DeviceFarm::TestGridProject","AWS::DMS::Certificate","AWS::DMS::Endpoint","AWS::DMS::EventSubscription","AWS::DMS::ReplicationSubnetGroup","AWS::DynamoDB::Table","AWS::EC2::CapacityReservation","AWS::EC2::CarrierGateway","AWS::EC2::ClientVpnEndpoint","AWS::EC2::CustomerGateway","AWS::EC2::DHCPOptions","AWS::EC2::EC2Fleet","AWS::EC2::EgressOnlyInternetGateway","AWS::EC2::EIP","AWS::EC2::FlowLog","AWS::EC2::Host","AWS::EC2::Instance","AWS::EC2::InternetGateway","AWS::EC2::IPAM","AWS::EC2::IPAMPool","AWS::EC2::IPAMScope","AWS::EC2::LaunchTemplate","AWS::EC2::NatGateway","AWS::EC2::NetworkAcl","AWS::EC2::NetworkInsightsAccessScope","AWS::EC2::NetworkInsightsAccessScopeAnalysis","AWS::EC2::NetworkInsightsAnalysis","AWS::EC2::NetworkInsightsPath","AWS::EC2::NetworkInterface","AWS::EC2::PrefixList","AWS::EC2::RegisteredHAInstance","AWS::EC2::RouteTable","AWS::EC2::SecurityGroup","AWS::EC2::SpotFleet","AWS::EC2::Subnet","AWS::EC2::SubnetRouteTableAssociation","AWS::EC2::TrafficMirrorFilter","AWS::EC2::TrafficMirrorSession","AWS::EC2::TrafficMirrorTarget","AWS::EC2::TransitGateway","AWS::EC2::TransitGatewayAttachment","AWS::EC2::TransitGatewayConnect","AWS::EC2::TransitGatewayMulticastDomain","AWS::EC2::TransitGatewayRouteTable","AWS::EC2::Volume","AWS::EC2::VPC","AWS::EC2::VPCEndpoint","AWS::EC2::VPCEndpointService","AWS::EC2::VPCPeeringConnection","AWS::EC2::VPNConnection","AWS::EC2::VPNGateway","AWS::ECR::PublicRepository","AWS::ECR::PullThroughCacheRule","AWS::ECR::RegistryPolicy","AWS::ECR::Repository","AWS::ECS::CapacityProvider","AWS::ECS::Cluster","AWS::ECS::Service","AWS::ECS::TaskDefinition","AWS::ECS::TaskSet","AWS::EFS::AccessPoint","AWS::EFS::FileSystem","AWS::EKS::Addon","AWS::EKS::Cluster","AWS::EKS::FargateProfile","AWS::EKS::IdentityProviderConfig","AWS::ElasticBeanstalk::Application","AWS::ElasticBeanstalk::ApplicationVersion","AWS::ElasticBeanstalk::Environment","AWS::ElasticLoadBalancing::LoadBalancer","AWS::ElasticLoadBalancingV2::Listener","AWS::ElasticLoadBalancingV2::LoadBalancer","AWS::Elasticsearch::Domain","AWS::EMR::SecurityConfiguration","AWS::Events::ApiDestination","AWS::Events::Archive","AWS::Events::Connection","AWS::Events::Endpoint","AWS::Events::EventBus","AWS::Events::Rule","AWS::EventSchemas::Discoverer","AWS::EventSchemas::Registry","AWS::EventSchemas::RegistryPolicy","AWS::EventSchemas::Schema","AWS::Evidently::Launch","AWS::Evidently::Project","AWS::FIS::ExperimentTemplate","AWS::Forecast::Dataset","AWS::Forecast::DatasetGroup","AWS::FraudDetector::EntityType","AWS::FraudDetector::Label","AWS::FraudDetector::Outcome","AWS::FraudDetector::Variable","AWS::GlobalAccelerator::Accelerator","AWS::GlobalAccelerator::EndpointGroup","AWS::GlobalAccelerator::Listener","AWS::Glue::Classifier","AWS::Glue::Job","AWS::Glue::MLTransform","AWS::Grafana::Workspace","AWS::GreengrassV2::ComponentVersion","AWS::GroundStation::Config","AWS::GroundStation::DataflowEndpointGroup","AWS::GroundStation::MissionProfile","AWS::GuardDuty::Detector","AWS::GuardDuty::Filter","AWS::GuardDuty::IPSet","AWS::GuardDuty::ThreatIntelSet","AWS::HealthLake::FHIRDatastore","AWS::IAM::Group","AWS::IAM::InstanceProfile","AWS::IAM::Policy","AWS::IAM::Role","AWS::IAM::SAMLProvider","AWS::IAM::ServerCertificate","AWS::IAM::User","AWS::ImageBuilder::ContainerRecipe","AWS::ImageBuilder::DistributionConfiguration","AWS::ImageBuilder::ImagePipeline","AWS::ImageBuilder::ImageRecipe","AWS::ImageBuilder::InfrastructureConfiguration","AWS::InspectorV2::Filter","AWS::IoT::AccountAuditConfiguration","AWS::IoT::Authorizer","AWS::IoT::CACertificate","AWS::IoT::CustomMetric","AWS::IoT::Dimension","AWS::IoT::FleetMetric","AWS::IoT::JobTemplate","AWS::IoT::MitigationAction","AWS::IoT::Policy","AWS::IoT::ProvisioningTemplate","AWS::IoT::RoleAlias","AWS::IoT::ScheduledAudit","AWS::IoT::SecurityProfile","AWS::IoTAnalytics::Channel","AWS::IoTAnalytics::Dataset","AWS::IoTAnalytics::Datastore","AWS::IoTAnalytics::Pipeline","AWS::IoTEvents::AlarmModel","AWS::IoTEvents::DetectorModel","AWS::IoTEvents::Input","AWS::IoTSiteWise::AssetModel","AWS::IoTSiteWise::Dashboard","AWS::IoTSiteWise::Gateway","AWS::IoTSiteWise::Portal","AWS::IoTSiteWise::Project","AWS::IoTTwinMaker::ComponentType","AWS::IoTTwinMaker::Entity","AWS::IoTTwinMaker::Scene","AWS::IoTTwinMaker::SyncJob","AWS::IoTTwinMaker::Workspace","AWS::IoTWireless::FuotaTask","AWS::IoTWireless::MulticastGroup","AWS::IoTWireless::ServiceProfile","AWS::IVS::Channel","AWS::IVS::PlaybackKeyPair","AWS::IVS::RecordingConfiguration","AWS::KafkaConnect::Connector","AWS::Kendra::Index","AWS::Kinesis::Stream","AWS::Kinesis::StreamConsumer","AWS::KinesisAnalyticsV2::Application","AWS::KinesisFirehose::DeliveryStream","AWS::KinesisVideo::SignalingChannel","AWS::KinesisVideo::Stream","AWS::KMS::Alias","AWS::KMS::Key","AWS::Lambda::CodeSigningConfig","AWS::Lambda::Function","AWS::Lex::Bot","AWS::Lex::BotAlias","AWS::Lightsail::Bucket","AWS::Lightsail::Certificate","AWS::Lightsail::Disk","AWS::Lightsail::StaticIp","AWS::Logs::Destination","AWS::LookoutMetrics::Alert","AWS::LookoutVision::Project","AWS::M2::Environment","AWS::MediaConnect::FlowEntitlement","AWS::MediaConnect::FlowSource","AWS::MediaConnect::FlowVpcInterface","AWS::MediaPackage::PackagingConfiguration","AWS::MediaPackage::PackagingGroup","AWS::MediaTailor::PlaybackConfiguration","AWS::MSK::BatchScramSecret","AWS::MSK::Cluster","AWS::MSK::Configuration","AWS::NetworkFirewall::Firewall","AWS::NetworkFirewall::FirewallPolicy","AWS::NetworkFirewall::RuleGroup","AWS::NetworkManager::ConnectPeer","AWS::NetworkManager::CustomerGatewayAssociation","AWS::NetworkManager::Device","AWS::NetworkManager::GlobalNetwork","AWS::NetworkManager::Link","AWS::NetworkManager::LinkAssociation","AWS::NetworkManager::Site","AWS::NetworkManager::TransitGatewayRegistration","AWS::OpenSearch::Domain","AWS::Panorama::Package","AWS::Personalize::Dataset","AWS::Personalize::DatasetGroup","AWS::Personalize::Schema","AWS::Personalize::Solution","AWS::Pinpoint::App","AWS::Pinpoint::ApplicationSettings","AWS::Pinpoint::Campaign","AWS::Pinpoint::EmailChannel","AWS::Pinpoint::EmailTemplate","AWS::Pinpoint::EventStream","AWS::Pinpoint::InAppTemplate","AWS::Pinpoint::Segment","AWS::QLDB::Ledger","AWS::QuickSight::DataSource","AWS::QuickSight::Template","AWS::QuickSight::Theme","AWS::RDS::DBCluster","AWS::RDS::DBClusterSnapshot","AWS::RDS::DBInstance","AWS::RDS::DBSecurityGroup","AWS::RDS::DBSnapshot","AWS::RDS::DBSubnetGroup","AWS::RDS::EventSubscription","AWS::RDS::GlobalCluster","AWS::RDS::OptionGroup","AWS::Redshift::Cluster","AWS::Redshift::ClusterParameterGroup","AWS::Redshift::ClusterSecurityGroup","AWS::Redshift::ClusterSnapshot","AWS::Redshift::ClusterSubnetGroup","AWS::Redshift::EndpointAccess","AWS::Redshift::EventSubscription","AWS::Redshift::ScheduledAction","AWS::ResilienceHub::App","AWS::ResilienceHub::ResiliencyPolicy","AWS::ResourceExplorer2::Index","AWS::RoboMaker::RobotApplication","AWS::RoboMaker::RobotApplicationVersion","AWS::RoboMaker::SimulationApplication","AWS::Route53::HostedZone","AWS::Route53RecoveryControl::Cluster","AWS::Route53RecoveryControl::ControlPanel","AWS::Route53RecoveryControl::RoutingControl","AWS::Route53RecoveryControl::SafetyRule","AWS::Route53RecoveryReadiness::Cell","AWS::Route53RecoveryReadiness::ReadinessCheck","AWS::Route53RecoveryReadiness::RecoveryGroup","AWS::Route53RecoveryReadiness::ResourceSet","AWS::Route53Resolver::FirewallDomainList","AWS::Route53Resolver::FirewallRuleGroup","AWS::Route53Resolver::FirewallRuleGroupAssociation","AWS::Route53Resolver::ResolverEndpoint","AWS::Route53Resolver::ResolverQueryLoggingConfig","AWS::Route53Resolver::ResolverQueryLoggingConfigAssociation","AWS::Route53Resolver::ResolverRule","AWS::Route53Resolver::ResolverRuleAssociation","AWS::RUM::AppMonitor","AWS::S3::AccessPoint","AWS::S3::AccountPublicAccessBlock","AWS::S3::Bucket","AWS::S3::MultiRegionAccessPoint","AWS::S3::StorageLens","AWS::SageMaker::AppImageConfig","AWS::SageMaker::CodeRepository","AWS::SageMaker::Domain","AWS::SageMaker::FeatureGroup","AWS::SageMaker::Image","AWS::SageMaker::Model","AWS::SageMaker::NotebookInstanceLifecycleConfig","AWS::SageMaker::Workteam","AWS::SecretsManager::Secret","AWS::ServiceCatalog::CloudFormationProduct","AWS::ServiceCatalog::CloudFormationProvisionedProduct","AWS::ServiceCatalog::Portfolio","AWS::ServiceDiscovery::HttpNamespace","AWS::ServiceDiscovery::Instance","AWS::ServiceDiscovery::PublicDnsNamespace","AWS::ServiceDiscovery::Service","AWS::SES::ConfigurationSet","AWS::SES::ContactList","AWS::SES::ReceiptFilter","AWS::SES::ReceiptRuleSet","AWS::SES::Template","AWS::Shield::Protection","AWS::ShieldRegional::Protection","AWS::Signer::SigningProfile","AWS::SNS::Topic","AWS::SQS::Queue","AWS::SSM::AssociationCompliance","AWS::SSM::Document","AWS::SSM::FileData","AWS::SSM::ManagedInstanceInventory","AWS::SSM::PatchCompliance","AWS::StepFunctions::Activity","AWS::StepFunctions::StateMachine","AWS::Transfer::Agreement","AWS::Transfer::Certificate","AWS::Transfer::Connector","AWS::Transfer::Workflow","AWS::WAF::RateBasedRule","AWS::WAF::Rule","AWS::WAF::RuleGroup","AWS::WAF::WebACL","AWS::WAFRegional::RateBasedRule","AWS::WAFRegional::Rule","AWS::WAFRegional::RuleGroup","AWS::WAFRegional::WebACL","AWS::WAFv2::IPSet","AWS::WAFv2::ManagedRuleSet","AWS::WAFv2::RegexPatternSet","AWS::WAFv2::RuleGroup","AWS::WAFv2::WebACL","AWS::WorkSpaces::ConnectionAlias","AWS::WorkSpaces::Workspace","AWS::XRay::EncryptionConfig"
            break
        }

        # Amazon.ConfigService.SortBy
        "Get-CFGConformancePackComplianceScoreList/SortBy"
        {
            $v = "SCORE"
            break
        }

        # Amazon.ConfigService.SortOrder
        "Get-CFGConformancePackComplianceScoreList/SortOrder"
        {
            $v = "ASCENDING","DESCENDING"
            break
        }


    }

    $v |
        Where-Object { $_ -like "$wordToComplete*" } |
        ForEach-Object { New-Object System.Management.Automation.CompletionResult $_, $_, 'ParameterValue', $_ }
}

$CFG_map = @{
    "ChronologicalOrder"=@("Get-CFGResourceConfigHistory")
    "ComplianceType"=@("Get-CFGAggregateComplianceDetailsByConfigRule")
    "ConfigRule_ConfigRuleState"=@("Write-CFGConfigRule")
    "ConfigRule_MaximumExecutionFrequency"=@("Write-CFGConfigRule")
    "ConfigSnapshotDeliveryProperties_DeliveryFrequency"=@("Write-CFGDeliveryChannel")
    "ConfigurationRecorder_RecordingScope"=@("Write-CFGConfigurationRecorder")
    "EvaluationMode"=@("Start-CFGResourceEvaluation")
    "ExternalEvaluation_ComplianceType"=@("Write-CFGExternalEvaluation")
    "Filters_ComplianceType"=@("Get-CFGAggregateComplianceByConfigRuleList","Get-CFGAggregateComplianceByConformancePack","Get-CFGConformancePackCompliance","Get-CFGConformancePackComplianceDetail")
    "Filters_EvaluationMode"=@("Get-CFGConfigRule","Get-CFGResourceEvaluationList")
    "Filters_MemberAccountRuleStatus"=@("Get-CFGOrganizationConfigRuleDetailedStatus")
    "Filters_ResourceType"=@("Get-CFGAggregateDiscoveredResourceCount")
    "Filters_Status"=@("Get-CFGOrganizationConformancePackDetailedStatus")
    "GroupByKey"=@("Get-CFGAggregateConfigRuleComplianceSummary","Get-CFGAggregateConformancePackComplianceSummary","Get-CFGAggregateDiscoveredResourceCount")
    "OrganizationCustomPolicyRuleMetadata_MaximumExecutionFrequency"=@("Write-CFGOrganizationConfigRule")
    "OrganizationCustomRuleMetadata_MaximumExecutionFrequency"=@("Write-CFGOrganizationConfigRule")
    "OrganizationManagedRuleMetadata_MaximumExecutionFrequency"=@("Write-CFGOrganizationConfigRule")
    "RecordingMode_RecordingFrequency"=@("Write-CFGConfigurationRecorder")
    "RecordingStrategy_UseOnly"=@("Write-CFGConfigurationRecorder")
    "ResourceDetails_ResourceConfigurationSchemaType"=@("Start-CFGResourceEvaluation")
    "ResourceIdentifier_ResourceType"=@("Get-CFGAggregateResourceConfig")
    "ResourceType"=@("Get-CFGAggregateDiscoveredResourceList","Get-CFGDiscoveredResource","Get-CFGResourceConfigHistory")
    "ResourceType_Type"=@("Write-CFGConfigurationAggregator")
    "ServicePrincipal_Type"=@("Write-CFGConfigurationAggregator")
    "SortBy"=@("Get-CFGConformancePackComplianceScoreList")
    "SortOrder"=@("Get-CFGConformancePackComplianceScoreList")
    "Source_Owner"=@("Write-CFGConfigRule")
}

_awsArgumentCompleterRegistration $CFG_Completers $CFG_map

$CFG_SelectCompleters = {
    param($commandName, $parameterName, $wordToComplete, $commandAst, $fakeBoundParameter)

    $cmdletType = Invoke-Expression "[Amazon.PowerShell.Cmdlets.CFG.$($commandName.Replace('-', ''))Cmdlet]"
    if (-not $cmdletType) {
        return
    }
    $awsCmdletAttribute = $cmdletType.GetCustomAttributes([Amazon.PowerShell.Common.AWSCmdletAttribute], $false)
    if (-not $awsCmdletAttribute) {
        return
    }
    $type = $awsCmdletAttribute.SelectReturnType
    if (-not $type) {
        return
    }

    $splitSelect = $wordToComplete -Split '\.'
    $splitSelect | Select-Object -First ($splitSelect.Length - 1) | ForEach-Object {
        $propertyName = $_
        $properties = $type.GetProperties(('Instance', 'Public', 'DeclaredOnly')) | Where-Object { $_.Name -ieq $propertyName }
        if ($properties.Length -ne 1) {
            break
        }
        $type = $properties.PropertyType
        $prefix += "$($properties.Name)."

        $asEnumerableType = $type.GetInterface('System.Collections.Generic.IEnumerable`1')
        if ($asEnumerableType -and $type -ne [System.String]) {
            $type =  $asEnumerableType.GetGenericArguments()[0]
        }
    }

    $v = @( '*' )
    $properties = $type.GetProperties(('Instance', 'Public', 'DeclaredOnly')).Name | Sort-Object
    if ($properties) {
        $v += ($properties | ForEach-Object { $prefix + $_ })
    }
    $parameters = $cmdletType.GetProperties(('Instance', 'Public')) | Where-Object { $_.GetCustomAttributes([System.Management.Automation.ParameterAttribute], $true) } | Select-Object -ExpandProperty Name | Sort-Object
    if ($parameters) {
        $v += ($parameters | ForEach-Object { "^$_" })
    }

    $v |
        Where-Object { $_ -match "^$([System.Text.RegularExpressions.Regex]::Escape($wordToComplete)).*" } |
        ForEach-Object { New-Object System.Management.Automation.CompletionResult $_, $_, 'ParameterValue', $_ }
}

$CFG_SelectMap = @{
    "Select"=@("Add-CFGResourceType",
               "Get-CFGAggregateResourceConfigBatch",
               "Get-CFGGetResourceConfigBatch",
               "Remove-CFGAggregationAuthorization",
               "Remove-CFGConfigRule",
               "Remove-CFGConfigurationAggregator",
               "Remove-CFGConfigurationRecorder",
               "Remove-CFGConformancePack",
               "Remove-CFGDeliveryChannel",
               "Remove-CFGEvaluationResult",
               "Remove-CFGOrganizationConfigRule",
               "Remove-CFGOrganizationConformancePack",
               "Remove-CFGPendingAggregationRequest",
               "Remove-CFGRemediationConfiguration",
               "Remove-CFGRemediationException",
               "Remove-CFGResourceConfig",
               "Remove-CFGRetentionConfiguration",
               "Remove-CFGServiceLinkedConfigurationRecorder",
               "Remove-CFGStoredQuery",
               "Submit-CFGConfigSnapshotDelivery",
               "Get-CFGAggregateComplianceByConfigRuleList",
               "Get-CFGAggregateComplianceByConformancePack",
               "Get-CFGAggregationAuthorizationList",
               "Get-CFGComplianceByConfigRule",
               "Get-CFGComplianceByResource",
               "Get-CFGConfigRuleEvaluationStatus",
               "Get-CFGConfigRule",
               "Get-CFGConfigurationAggregatorList",
               "Get-CFGConfigurationAggregatorSourcesStatus",
               "Get-CFGConfigurationRecorder",
               "Get-CFGConfigurationRecorderStatus",
               "Get-CFGConformancePackCompliance",
               "Get-CFGConformancePack",
               "Get-CFGConformancePackStatus",
               "Get-CFGDeliveryChannel",
               "Get-CFGDeliveryChannelStatus",
               "Get-CFGOrganizationConfigRule",
               "Get-CFGOrganizationConfigRuleStatus",
               "Get-CFGOrganizationConformancePack",
               "Get-CFGOrganizationConformancePackStatus",
               "Get-CFGPendingAggregationRequestList",
               "Get-CFGRemediationConfiguration",
               "Get-CFGRemediationException",
               "Get-CFGRemediationExecutionStatus",
               "Get-CFGRetentionConfiguration",
               "Remove-CFGResourceType",
               "Get-CFGAggregateComplianceDetailsByConfigRule",
               "Get-CFGAggregateConfigRuleComplianceSummary",
               "Get-CFGAggregateConformancePackComplianceSummary",
               "Get-CFGAggregateDiscoveredResourceCount",
               "Get-CFGAggregateResourceConfig",
               "Get-CFGComplianceDetailsByConfigRule",
               "Get-CFGComplianceDetailsByResource",
               "Get-CFGComplianceSummaryByConfigRule",
               "Get-CFGComplianceSummaryByResourceType",
               "Get-CFGConformancePackComplianceDetail",
               "Get-CFGConformancePackComplianceSummary",
               "Get-CFGCustomRulePolicy",
               "Get-CFGDiscoveredResourceCount",
               "Get-CFGOrganizationConfigRuleDetailedStatus",
               "Get-CFGOrganizationConformancePackDetailedStatus",
               "Get-CFGOrganizationCustomRulePolicy",
               "Get-CFGResourceConfigHistory",
               "Get-CFGResourceEvaluationSummary",
               "Get-CFGStoredQuery",
               "Get-CFGAggregateDiscoveredResourceList",
               "Get-CFGConfigurationRecorderList",
               "Get-CFGConformancePackComplianceScoreList",
               "Get-CFGDiscoveredResource",
               "Get-CFGResourceEvaluationList",
               "Get-CFGStoredQueryList",
               "Get-CFGResourceTag",
               "Write-CFGAggregationAuthorization",
               "Write-CFGConfigRule",
               "Write-CFGConfigurationAggregator",
               "Write-CFGConfigurationRecorder",
               "Write-CFGConformancePack",
               "Write-CFGDeliveryChannel",
               "Write-CFGEvaluation",
               "Write-CFGExternalEvaluation",
               "Write-CFGOrganizationConfigRule",
               "Write-CFGOrganizationConformancePack",
               "Write-CFGRemediationConfiguration",
               "Write-CFGRemediationException",
               "Write-CFGResourceConfig",
               "Write-CFGRetentionConfiguration",
               "Write-CFGServiceLinkedConfigurationRecorder",
               "Write-CFGStoredQuery",
               "Select-CFGAggregateResourceConfig",
               "Select-CFGResourceConfig",
               "Start-CFGConfigRulesEvaluation",
               "Start-CFGConfigurationRecorder",
               "Start-CFGRemediationExecution",
               "Start-CFGResourceEvaluation",
               "Stop-CFGConfigurationRecorder",
               "Add-CFGResourceTag",
               "Remove-CFGResourceTag")
}

_awsArgumentCompleterRegistration $CFG_SelectCompleters $CFG_SelectMap


# SIG # Begin signature block
# MIIueAYJKoZIhvcNAQcCoIIuaTCCLmUCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCXrK3pIKReeLYE
# ZcyDWP1ylwzQnAAeykvY7+L2XZ141aCCE+owggXAMIIEqKADAgECAhAP0bvKeWvX
# +N1MguEKmpYxMA0GCSqGSIb3DQEBCwUAMGwxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xKzApBgNV
# BAMTIkRpZ2lDZXJ0IEhpZ2ggQXNzdXJhbmNlIEVWIFJvb3QgQ0EwHhcNMjIwMTEz
# MDAwMDAwWhcNMzExMTA5MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMM
# RGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQD
# ExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwggIiMA0GCSqGSIb3DQEBAQUAA4IC
# DwAwggIKAoICAQC/5pBzaN675F1KPDAiMGkz7MKnJS7JIT3yithZwuEppz1Yq3aa
# za57G4QNxDAf8xukOBbrVsaXbR2rsnnyyhHS5F/WBTxSD1Ifxp4VpX6+n6lXFllV
# cq9ok3DCsrp1mWpzMpTREEQQLt+C8weE5nQ7bXHiLQwb7iDVySAdYyktzuxeTsiT
# +CFhmzTrBcZe7FsavOvJz82sNEBfsXpm7nfISKhmV1efVFiODCu3T6cw2Vbuyntd
# 463JT17lNecxy9qTXtyOj4DatpGYQJB5w3jHtrHEtWoYOAMQjdjUN6QuBX2I9YI+
# EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsDdV14Ztk6MUSaM0C/CNdaSaTC5qmgZ92k
# J7yhTzm1EVgX9yRcRo9k98FpiHaYdj1ZXUJ2h4mXaXpI8OCiEhtmmnTK3kse5w5j
# rubU75KSOp493ADkRSWJtppEGSt+wJS00mFt6zPZxd9LBADMfRyVw4/3IbKyEbe7
# f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hkpjPRiQfhvbfmQ6QYuKZ3AeEPlAwhHbJU
# KSWJbOUOUlFHdL4mrLZBdd56rF+NP8m800ERElvlEFDrMcXKchYiCd98THU/Y+wh
# X8QgUWtvsauGi0/C1kVfnSD8oR7FwI+isX4KJpn15GkvmB0t9dmpsh3lGwIDAQAB
# o4IBZjCCAWIwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wHwYDVR0jBBgwFoAUsT7DaQP4v0cB1JgmGggC72NkK8MwDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMH8GCCsGAQUFBwEBBHMwcTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEkGCCsGAQUFBzAC
# hj1odHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRIaWdoQXNzdXJh
# bmNlRVZSb290Q0EuY3J0MEsGA1UdHwREMEIwQKA+oDyGOmh0dHA6Ly9jcmwzLmRp
# Z2ljZXJ0LmNvbS9EaWdpQ2VydEhpZ2hBc3N1cmFuY2VFVlJvb3RDQS5jcmwwHAYD
# VR0gBBUwEzAHBgVngQwBAzAIBgZngQwBBAEwDQYJKoZIhvcNAQELBQADggEBAEHx
# qRH0DxNHecllao3A7pgEpMbjDPKisedfYk/ak1k2zfIe4R7sD+EbP5HU5A/C5pg0
# /xkPZigfT2IxpCrhKhO61z7H0ZL+q93fqpgzRh9Onr3g7QdG64AupP2uU7SkwaT1
# IY1rzAGt9Rnu15ClMlIr28xzDxj4+87eg3Gn77tRWwR2L62t0+od/P1Tk+WMieNg
# GbngLyOOLFxJy34riDkruQZhiPOuAnZ2dMFkkbiJUZflhX0901emWG4f7vtpYeJa
# 3Cgh6GO6Ps9W7Zrk9wXqyvPsEt84zdp7PiuTUy9cUQBY3pBIowrHC/Q7bVUx8ALM
# R3eWUaNetbxcyEMRoacwggawMIIEmKADAgECAhAIrUCyYNKcTJ9ezam9k67ZMA0G
# CSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0zNjA0MjgyMzU5NTla
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDVtC9C
# 0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0JAfhS0/TeEP0F9ce
# 2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJrQ5qZ8sU7H/Lvy0da
# E6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhFLqGfLOEYwhrMxe6T
# SXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+FLEikVoQ11vkunKoA
# FdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh3K3kGKDYwSNHR7Oh
# D26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJwZPt4bRc4G/rJvmM
# 1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQayg9Rc9hUZTO1i4F4z
# 8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbIYViY9XwCFjyDKK05
# huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchApQfDVxW0mdmgRQRNY
# mtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRroOBl8ZhzNeDhFMJlP
# /2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IBWTCCAVUwEgYDVR0T
# AQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHwYD
# VR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNV
# HR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRU
# cnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAEDMAgGBmeBDAEEATAN
# BgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql+Eg08yy25nRm95Ry
# sQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFFUP2cvbaF4HZ+N3HL
# IvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1hmYFW9snjdufE5Btf
# Q/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3RywYFzzDaju4ImhvTnh
# OE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5UbdldAhQfQDN8A+KVssIh
# dXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw8MzK7/0pNVwfiThV
# 9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnPLqR0kq3bPKSchh/j
# wVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatEQOON8BUozu3xGFYH
# Ki8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bnKD+sEq6lLyJsQfmC
# XBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQjiWQ1tygVQK+pKHJ6l
# /aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbqyK+p/pQd52MbOoZW
# eE4wggduMIIFVqADAgECAhAOG4Qdo7UmBpSv170eUaMrMA0GCSqGSIb3DQEBCwUA
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwHhcNMjQwODAyMDAwMDAwWhcNMjUwODAxMjM1OTU5WjCB9jET
# MBEGCysGAQQBgjc8AgEDEwJVUzEZMBcGCysGAQQBgjc8AgECEwhEZWxhd2FyZTEd
# MBsGA1UEDwwUUHJpdmF0ZSBPcmdhbml6YXRpb24xEDAOBgNVBAUTBzQxNTI5NTQx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdTZWF0
# dGxlMSIwIAYDVQQKExlBbWF6b24gV2ViIFNlcnZpY2VzLCBJbmMuMRcwFQYDVQQL
# Ew5TREtzIGFuZCBUb29sczEiMCAGA1UEAxMZQW1hem9uIFdlYiBTZXJ2aWNlcywg
# SW5jLjCCAaIwDQYJKoZIhvcNAQEBBQADggGPADCCAYoCggGBAJn5K00vaam9Tsax
# bhWuOwBweiOIeGUkpi0F5SYcPijYzpnd7vS0G3WYbFuSTGKipaRe37VDHdNa9Y1F
# faRSBrKmeNytBzNsnIUtiKl5OWuQkbaNcH/8XHwPOf6szaqz6wnnkhj0Bv0zA+Ih
# IVAyPg7T8bqJRkGfOf5ugIH06fPVFj1KWuugiXNs1/M4/FLyBLsSJZbfvID+TVWO
# 2YjFBLDDVrOB7rw22KJYl4w1q+wfUUm05uRX5I+uLiRaT88l1MZHLwHg1nuL0Vm9
# t41X2xTOn4QeqxIXo1BbcVfiyjPogrU9xHUs2B1JyEVZWjv4VUwfOW0X3er1Ukwn
# Kqxsjg/2ikAT4oRjFgWnLsU0VoRDkkShhfVtC5pSB6v/v0gzgReQNqElCVcKwOHj
# fiTzbRRWHFwYzNwEqnSAhC+qB/zYXWg9KBF1DtVcWVLaHMXuLn0plnHWA/AoPZcl
# hc7HjClr15RcrHl6pcclBHtRBtJkX7jLlC7cAWkob+4Wp/QyVwIDAQABo4ICAjCC
# Af4wHwYDVR0jBBgwFoAUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHQYDVR0OBBYEFAa4
# CewhP0BkYi71XHKKI9o8p1BMMD0GA1UdIAQ2MDQwMgYFZ4EMAQMwKTAnBggrBgEF
# BQcCARYbaHR0cDovL3d3dy5kaWdpY2VydC5jb20vQ1BTMA4GA1UdDwEB/wQEAwIH
# gDATBgNVHSUEDDAKBggrBgEFBQcDAzCBtQYDVR0fBIGtMIGqMFOgUaBPhk1odHRw
# Oi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmlu
# Z1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNybDBToFGgT4ZNaHR0cDovL2NybDQuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hB
# Mzg0MjAyMUNBMS5jcmwwgZQGCCsGAQUFBwEBBIGHMIGEMCQGCCsGAQUFBzABhhho
# dHRwOi8vb2NzcC5kaWdpY2VydC5jb20wXAYIKwYBBQUHMAKGUGh0dHA6Ly9jYWNl
# cnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNB
# NDA5NlNIQTM4NDIwMjFDQTEuY3J0MAkGA1UdEwQCMAAwDQYJKoZIhvcNAQELBQAD
# ggIBAISiRgUmPdqs8OdhLLJ8Blj9EmNwt3MNQszq45nw9ApvgRRXBYFTA/5JFJQv
# 4k3qqAeOlt0vbGnzDHVzWq7JEGJZrUn7qfkmj4jflPJ1c6iOCUZFb8+x+45K/9ks
# o4yS4Y3M2gCDKJMrKmgyhm/qZL2oXbViT3XB4iVYr/+eHLf+146UWYrYtR5clim9
# FM1tkXV9n4gk+h5FRgSDXoqSiwoyM60ziNutQAKsNAHjnazBWRluKwhtpVMRuHu8
# 1SbIeTJ/xz0F2P90vmMu2SBhtsnO4QL3uMznLJ6qvAQVfny/T2bMSSPROHIXSDvA
# qCThkA49Gi/5NXKmMs8ukZzLOkTEx8V5uKxEf4gI9q17oLYG8oX5e+FlldVpxRRf
# kru1RtPu4MCAzvLYTdLgk9Rovglztgic8gQNSQO/pjHX7zAZ5Ys+M4japyzrzhwK
# yCwfnKWAv8b+5pqSsJh4bdoXQtGBP/QOiKjD3+ip/D36hw4ZKYoVu5XJu+rnY+or
# 8dXYA9uaZYrVGLH16W8bidzPT3wCcBOWcod4WHQW+Rk2AoRLAj2Nj+TxwlDIDQkA
# SD/n7Sm0FLFzjBmPD5YfFu58jefNV2HW3aBFuM+1e0VyjuRPz+dmP0vG8HVL8ste
# NxL0ev/CF619Ef4FsUgUwTSV0IvDtgYkxlbtwuzHqYSWUFo4MYIZ5DCCGeACAQEw
# fTBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNV
# BAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgQ29kZSBTaWduaW5nIFJTQTQwOTYgU0hB
# Mzg0IDIwMjEgQ0ExAhAOG4Qdo7UmBpSv170eUaMrMA0GCWCGSAFlAwQCAQUAoHww
# EAYKKwYBBAGCNwIBDDECMAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEILU9DySw
# KZ2UrXOcnTevbi/0Pt3+f0/0pa0Xg7GEDM/iMA0GCSqGSIb3DQEBAQUABIIBgJTV
# 3gNow2xrJEbbJZ9I/Q8OvxeCw5pCXVnt4VMqWBt45rJh3GThQ5n0oAdAVLOP0Ane
# ho9idihUYR707taWRFznQBcxHgRBtJkQ4hoCAbZvFXUneBkv99fYWxQziHkB9zgv
# GDfOsgDo7ShVUi29wIVjxaGD9g21Oq20LYgXhDRpkSdsX3CDoLwGEgOjPGlGlKM/
# szYn/1cfx75YIKttddHeJbfbc/gA93PMMVDtSlJ4ahshIkN9DRQjZXVglq0BXN4H
# FsAKhcQViu3xVqHhn45uuDNtPS+UrD0W1kwo+sSlR+NQc5PiiC4nEGcaKBnE5Qve
# hPQ8LekDampgTSMcV/jukHkavjdeC69z9WyEU/AVGufEcm5HqpU0Yf4fHMBQ8VYb
# vO2kOjUtpCQpPmAhnnhn2wnwO5bkCynw9ShJWpPQt79tYMP7h6kcTa8vRpJ7kbg9
# x49xgQ1a+eBq2wscNAxxJ962XH2/FehbadboDPxjmJ2nM6w0zbtWLJJC5c2XIaGC
# Fzowghc2BgorBgEEAYI3AwMBMYIXJjCCFyIGCSqGSIb3DQEHAqCCFxMwghcPAgED
# MQ8wDQYJYIZIAWUDBAIBBQAweAYLKoZIhvcNAQkQAQSgaQRnMGUCAQEGCWCGSAGG
# /WwHATAxMA0GCWCGSAFlAwQCAQUABCDdwH2i4wLIvXG1s8OOQE9E31G3aZO07mtR
# eSM1PpNgIwIRAOStbEFrxivzvCNTzXe2MzIYDzIwMjUwMjA2MjE1MTE1WqCCEwMw
# gga8MIIEpKADAgECAhALrma8Wrp/lYfG+ekE4zMEMA0GCSqGSIb3DQEBCwUAMGMx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMy
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcg
# Q0EwHhcNMjQwOTI2MDAwMDAwWhcNMzUxMTI1MjM1OTU5WjBCMQswCQYDVQQGEwJV
# UzERMA8GA1UEChMIRGlnaUNlcnQxIDAeBgNVBAMTF0RpZ2lDZXJ0IFRpbWVzdGFt
# cCAyMDI0MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAvmpzn/aVIauW
# MLpbbeZZo7Xo/ZEfGMSIO2qZ46XB/QowIEMSvgjEdEZ3v4vrrTHleW1JWGErrjOL
# 0J4L0HqVR1czSzvUQ5xF7z4IQmn7dHY7yijvoQ7ujm0u6yXF2v1CrzZopykD07/9
# fpAT4BxpT9vJoJqAsP8YuhRvflJ9YeHjes4fduksTHulntq9WelRWY++TFPxzZrb
# ILRYynyEy7rS1lHQKFpXvo2GePfsMRhNf1F41nyEg5h7iOXv+vjX0K8RhUisfqw3
# TTLHj1uhS66YX2LZPxS4oaf33rp9HlfqSBePejlYeEdU740GKQM7SaVSH3TbBL8R
# 6HwX9QVpGnXPlKdE4fBIn5BBFnV+KwPxRNUNK6lYk2y1WSKour4hJN0SMkoaNV8h
# yyADiX1xuTxKaXN12HgR+8WulU2d6zhzXomJ2PleI9V2yfmfXSPGYanGgxzqI+Sh
# oOGLomMd3mJt92nm7Mheng/TBeSA2z4I78JpwGpTRHiT7yHqBiV2ngUIyCtd0pZ8
# zg3S7bk4QC4RrcnKJ3FbjyPAGogmoiZ33c1HG93Vp6lJ415ERcC7bFQMRbxqrMVA
# Niav1k425zYyFMyLNyE1QulQSgDpW9rtvVcIH7WvG9sqYup9j8z9J1XqbBZPJ5XL
# ln8mS8wWmdDLnBHXgYly/p1DhoQo5fkCAwEAAaOCAYswggGHMA4GA1UdDwEB/wQE
# AwIHgDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMCAGA1Ud
# IAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATAfBgNVHSMEGDAWgBS6FtltTYUv
# cyl2mi91jGogj57IbzAdBgNVHQ4EFgQUn1csA3cOKBWQZqVjXu5Pkh92oFswWgYD
# VR0fBFMwUTBPoE2gS4ZJaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNybDCBkAYIKwYB
# BQUHAQEEgYMwgYAwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNv
# bTBYBggrBgEFBQcwAoZMaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lD
# ZXJ0VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNydDANBgkq
# hkiG9w0BAQsFAAOCAgEAPa0eH3aZW+M4hBJH2UOR9hHbm04IHdEoT8/T3HuBSyZe
# q3jSi5GXeWP7xCKhVireKCnCs+8GZl2uVYFvQe+pPTScVJeCZSsMo1JCoZN2mMew
# /L4tpqVNbSpWO9QGFwfMEy60HofN6V51sMLMXNTLfhVqs+e8haupWiArSozyAmGH
# /6oMQAh078qRh6wvJNU6gnh5OruCP1QUAvVSu4kqVOcJVozZR5RRb/zPd++PGE3q
# F1P3xWvYViUJLsxtvge/mzA75oBfFZSbdakHJe2BVDGIGVNVjOp8sNt70+kEoMF+
# T6tptMUNlehSR7vM+C13v9+9ZOUKzfRUAYSyyEmYtsnpltD/GWX8eM70ls1V6QG/
# ZOB6b6Yum1HvIiulqJ1Elesj5TMHq8CWT/xrW7twipXTJ5/i5pkU5E16RSBAdOp1
# 2aw8IQhhA/vEbFkEiF2abhuFixUDobZaA0VhqAsMHOmaT3XThZDNi5U2zHKhUs5u
# HHdG6BoQau75KiNbh0c+hatSF+02kULkftARjsyEpHKsF7u5zKRbt5oK5YGwFvgc
# 4pEVUNytmB3BpIiowOIIuDgP5M9WArHYSAR16gc0dP2XdkMEP5eBsX7bf/MGN4K3
# HP50v/01ZHo/Z5lGLvNwQ7XHBx1yomzLP8lx4Q1zZKDyHcp4VQJLu2kWTsKsOqQw
# ggauMIIElqADAgECAhAHNje3JFR82Ees/ShmKl5bMA0GCSqGSIb3DQEBCwUAMGIx
# CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3
# dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBH
# NDAeFw0yMjAzMjMwMDAwMDBaFw0zNzAzMjIyMzU5NTlaMGMxCzAJBgNVBAYTAlVT
# MRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNlcnQgVHJ1
# c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0EwggIiMA0GCSqG
# SIb3DQEBAQUAA4ICDwAwggIKAoICAQDGhjUGSbPBPXJJUVXHJQPE8pE3qZdRodbS
# g9GeTKJtoLDMg/la9hGhRBVCX6SI82j6ffOciQt/nR+eDzMfUBMLJnOWbfhXqAJ9
# /UO0hNoR8XOxs+4rgISKIhjf69o9xBd/qxkrPkLcZ47qUT3w1lbU5ygt69OxtXXn
# HwZljZQp09nsad/ZkIdGAHvbREGJ3HxqV3rwN3mfXazL6IRktFLydkf3YYMZ3V+0
# VAshaG43IbtArF+y3kp9zvU5EmfvDqVjbOSmxR3NNg1c1eYbqMFkdECnwHLFuk4f
# sbVYTXn+149zk6wsOeKlSNbwsDETqVcplicu9Yemj052FVUmcJgmf6AaRyBD40Nj
# gHt1biclkJg6OBGz9vae5jtb7IHeIhTZgirHkr+g3uM+onP65x9abJTyUpURK1h0
# QCirc0PO30qhHGs4xSnzyqqWc0Jon7ZGs506o9UD4L/wojzKQtwYSH8UNM/STKvv
# mz3+DrhkKvp1KCRB7UK/BZxmSVJQ9FHzNklNiyDSLFc1eSuo80VgvCONWPfcYd6T
# /jnA+bIwpUzX6ZhKWD7TA4j+s4/TXkt2ElGTyYwMO1uKIqjBJgj5FBASA31fI7tk
# 42PgpuE+9sJ0sj8eCXbsq11GdeJgo1gJASgADoRU7s7pXcheMBK9Rp6103a50g5r
# mQzSM7TNsQIDAQABo4IBXTCCAVkwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4E
# FgQUuhbZbU2FL3MpdpovdYxqII+eyG8wHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMIMHcG
# CCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQu
# Y29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGln
# aUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8v
# Y3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAgBgNV
# HSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggIB
# AH1ZjsCTtm+YqUQiAX5m1tghQuGwGC4QTRPPMFPOvxj7x1Bd4ksp+3CKDaopafxp
# wc8dB+k+YMjYC+VcW9dth/qEICU0MWfNthKWb8RQTGIdDAiCqBa9qVbPFXONASIl
# zpVpP0d3+3J0FNf/q0+KLHqrhc1DX+1gtqpPkWaeLJ7giqzl/Yy8ZCaHbJK9nXzQ
# cAp876i8dU+6WvepELJd6f8oVInw1YpxdmXazPByoyP6wCeCRK6ZJxurJB4mwbfe
# Kuv2nrF5mYGjVoarCkXJ38SNoOeY+/umnXKvxMfBwWpx2cYTgAnEtp/Nh4cku0+j
# Sbl3ZpHxcpzpSwJSpzd+k1OsOx0ISQ+UzTl63f8lY5knLD0/a6fxZsNBzU+2QJsh
# IUDQtxMkzdwdeDrknq3lNHGS1yZr5Dhzq6YBT70/O3itTK37xJV77QpfMzmHQXh6
# OOmc4d0j/R0o08f56PGYX/sr2H7yRp11LB4nLCbbbxV7HhmLNriT1ObyF5lZynDw
# N7+YAN8gFk8n+2BnFqFmut1VwDophrCYoCvtlUG3OtUVmDG0YgkPCr2B2RP+v6TR
# 81fZvAT6gt4y3wSJ8ADNXcL50CN/AAvkdgIm2fBldkKmKYcJRyvmfxqkhQ/8mJb2
# VVQrH4D6wPIOK+XW+6kvRBVK5xMOHds3OBqhK/bt1nz8MIIFjTCCBHWgAwIBAgIQ
# DpsYjvnQLefv21DiCEAYWjANBgkqhkiG9w0BAQwFADBlMQswCQYDVQQGEwJVUzEV
# MBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29t
# MSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMjIwODAx
# MDAwMDAwWhcNMzExMTA5MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMM
# RGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQD
# ExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwggIiMA0GCSqGSIb3DQEBAQUAA4IC
# DwAwggIKAoICAQC/5pBzaN675F1KPDAiMGkz7MKnJS7JIT3yithZwuEppz1Yq3aa
# za57G4QNxDAf8xukOBbrVsaXbR2rsnnyyhHS5F/WBTxSD1Ifxp4VpX6+n6lXFllV
# cq9ok3DCsrp1mWpzMpTREEQQLt+C8weE5nQ7bXHiLQwb7iDVySAdYyktzuxeTsiT
# +CFhmzTrBcZe7FsavOvJz82sNEBfsXpm7nfISKhmV1efVFiODCu3T6cw2Vbuyntd
# 463JT17lNecxy9qTXtyOj4DatpGYQJB5w3jHtrHEtWoYOAMQjdjUN6QuBX2I9YI+
# EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsDdV14Ztk6MUSaM0C/CNdaSaTC5qmgZ92k
# J7yhTzm1EVgX9yRcRo9k98FpiHaYdj1ZXUJ2h4mXaXpI8OCiEhtmmnTK3kse5w5j
# rubU75KSOp493ADkRSWJtppEGSt+wJS00mFt6zPZxd9LBADMfRyVw4/3IbKyEbe7
# f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hkpjPRiQfhvbfmQ6QYuKZ3AeEPlAwhHbJU
# KSWJbOUOUlFHdL4mrLZBdd56rF+NP8m800ERElvlEFDrMcXKchYiCd98THU/Y+wh
# X8QgUWtvsauGi0/C1kVfnSD8oR7FwI+isX4KJpn15GkvmB0t9dmpsh3lGwIDAQAB
# o4IBOjCCATYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wHwYDVR0jBBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDgYDVR0P
# AQH/BAQDAgGGMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29j
# c3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MEUGA1UdHwQ+MDww
# OqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RFJvb3RDQS5jcmwwEQYDVR0gBAowCDAGBgRVHSAAMA0GCSqGSIb3DQEBDAUAA4IB
# AQBwoL9DXFXnOF+go3QbPbYW1/e/Vwe9mqyhhyzshV6pGrsi+IcaaVQi7aSId229
# GhT0E0p6Ly23OO/0/4C5+KH38nLeJLxSA8hO0Cre+i1Wz/n096wwepqLsl7Uz9FD
# RJtDIeuWcqFItJnLnU+nBgMTdydE1Od/6Fmo8L8vC6bp8jQ87PcDx4eo0kxAGTVG
# amlUsLihVo7spNU96LHc/RzY9HdaXFSMb++hUD38dglohJ9vytsgjTVgHAIDyyCw
# rFigDkBjxZgiwbJZ9VVrzyerbHbObyMt9H5xaiNrIv8SuFQtJ37YOtnwtoeW/VvR
# XKwYw02fc7cBqZ9Xql4o4rmUMYIDdjCCA3ICAQEwdzBjMQswCQYDVQQGEwJVUzEX
# MBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0
# ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5nIENBAhALrma8Wrp/lYfG
# +ekE4zMEMA0GCWCGSAFlAwQCAQUAoIHRMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0B
# CRABBDAcBgkqhkiG9w0BCQUxDxcNMjUwMjA2MjE1MTE1WjArBgsqhkiG9w0BCRAC
# DDEcMBowGDAWBBTb04XuYtvSPnvk9nFIUIck1YZbRTAvBgkqhkiG9w0BCQQxIgQg
# nw43EAThvZ/4+L3t4ANIArt13/UBnw/zqIhvStHUMgwwNwYLKoZIhvcNAQkQAi8x
# KDAmMCQwIgQgdnafqPJjLx9DCzojMK7WVnX+13PbBdZluQWTmEOPmtswDQYJKoZI
# hvcNAQEBBQAEggIApdBkOWbt7uipHIYXfSYwP5vdJhv4STFyhE+UHMoDuaXbB88Y
# aLk7x2tEteDJKoQjyN7/3lgxI0Yy/JB9h/q7FLmfp694JdDwa2pGGebiWplnUiD8
# gNlVwPOMGRO4Oe0Y+C9wEqplwAbzxfldbn0RMuSqBzOiclUbep+qIDaGkdb15wNb
# Yw74ykLPuQDigExsIHf6GKOi57alxaMJqBww6hwRcoeWp8tNZM0aSsqlk4R68e41
# +ShR8bVkGlOXRG4b/WsQ30fl5NaL89YdANK12EKYvwegSXHuyL2QUAhNNIj8hOj+
# FXnhANAG+dXhC8kxn1tmdAximtHRZZ7nZsM9fpuHDLLOrm1VyOybPndRNOKp+l4V
# 8EN54/DSz93A8f9O0UM5uFBcN13NqQ4zTQOI9zrWD9VqzLtjekS/IfGNbzGvk8LE
# nqgvZmjbaUWt06/9JTBk24EDSnybhG10CucIkU9i0D2f1HF+oVdWlfvqjygVIauD
# Nd7JBdvOWiDD9FpnOr/rtIASY8QMAxO/KTiCcSZm5qbZ5yb1JtFOmJq1xK3QXnBO
# FdVjTGbekMGU2bRr5xtrrhYOj+DOPl48MdInhE41znjkIGNx33wK0KW5bZhTda3+
# G6ETUQe+XUhbXj7e18DJUjvAMgAwJGfJ6EfcZPXVEYfMeiY1/8An/d5iz+M=
# SIG # End signature block
