﻿# Shell Configuration
Set-Alias -Name Clear-AWSCredentials -Value Clear-AWSCredential
Set-Alias -Name Clear-AWSDefaults -Value Clear-AWSDefaultConfiguration
Set-Alias -Name Get-AWSCredentials -Value Get-AWSCredential
Set-Alias -Name Initialize-AWSDefaults -Value Initialize-AWSDefaultConfiguration
Set-Alias -Name New-AWSCredentials -Value New-AWSCredential
Set-Alias -Name Set-AWSCredentials -Value Set-AWSCredential

# ApiGatewayV2
Set-Alias -Name Get-AG2ApiLis -Value Get-AG2ApiList

# ApplicationAutoScaling
Set-Alias -Name Write-AASScalingPolicy -Value Set-AASScalingPolicy

# ApplicationDiscoveryService
Set-Alias -Name Remove-ADSApplications -Value Remove-ADSApplication

# AutoScaling
Set-Alias -Name Add-ASInstances -Value Mount-ASInstance
Set-Alias -Name Dismount-ASInstances -Value Dismount-ASInstance
Set-Alias -Name Get-ASAccountLimits -Value Get-ASAccountLimit
Set-Alias -Name Get-ASLifecycleHooks -Value Get-ASLifecycleHook
Set-Alias -Name Get-ASLifecycleHookTypes -Value Get-ASLifecycleHookType

# AWSSupport
Set-Alias -Name Get-ASACases -Value Get-ASACase
Set-Alias -Name Get-ASACommunications -Value Get-ASACommunication
Set-Alias -Name Get-ASAServices -Value Get-ASAService
Set-Alias -Name Get-ASASeverityLevels -Value Get-ASASeverityLevel
Set-Alias -Name Get-ASATrustedAdvisorCheckRefreshStatuses -Value Get-ASATrustedAdvisorCheckRefreshStatus
Set-Alias -Name Get-ASATrustedAdvisorChecks -Value Get-ASATrustedAdvisorCheck
Set-Alias -Name Get-ASATrustedAdvisorCheckSummaries -Value Get-ASATrustedAdvisorCheckSummary

# Backup
Set-Alias -Name Remove-BAKBackupVaultNotifications -Value Remove-BAKBackupVaultNotification

# Batch
Set-Alias -Name Get-BATJobsList -Value Get-BATJobList

# CloudFormation
Set-Alias -Name Get-CFNAccountLimits -Value Get-CFNAccountLimit
Set-Alias -Name Get-CFNStackEvents -Value Get-CFNStackEvent
Set-Alias -Name Get-CFNStackResources -Value Get-CFNStackResourceList
Set-Alias -Name Get-CFNStackResourceSummaries -Value Get-CFNStackResourceSummary
Set-Alias -Name Get-CFNStackSummaries -Value Get-CFNStackSummary

# CloudFront
Set-Alias -Name Get-CFCloudFrontOriginAccessIdentities -Value Get-CFCloudFrontOriginAccessIdentityList
Set-Alias -Name Get-CFDistributions -Value Get-CFDistributionList
Set-Alias -Name Get-CFInvalidations -Value Get-CFInvalidationList
Set-Alias -Name Get-CFStreamingDistributions -Value Get-CFStreamingDistributionList

# CloudHSM
Set-Alias -Name Get-HSMAvailableZones -Value Get-HSMAvailableZone

# CloudSearch
Set-Alias -Name Get-CSAnalysisSchemes -Value Get-CSAnalysisScheme
Set-Alias -Name Get-CSAvailabilityOptions -Value Get-CSAvailabilityOption
Set-Alias -Name Get-CSIndexFields -Value Get-CSIndexField
Set-Alias -Name Get-CSListDomainNames -Value Get-CSDomainNameList
Set-Alias -Name Get-CSScalingParameters -Value Get-CSScalingParameter
Set-Alias -Name Get-CSServiceAccessPolicies -Value Get-CSServiceAccessPolicy
Set-Alias -Name Update-CSAvailabilityOptions -Value Update-CSAvailabilityOption
Set-Alias -Name Update-CSScalingParameters -Value Update-CSScalingParameter
Set-Alias -Name Update-CSServiceAccessPolicies -Value Update-CSServiceAccessPolicy

# CloudSearchDomain
Set-Alias -Name Get-CSDSuggestions -Value Get-CSDSuggestion
Set-Alias -Name Search-CSDDocuments -Value Search-CSDDocument
Set-Alias -Name Write-CSDDocuments -Value Write-CSDDocument

# CloudTrail
Set-Alias -Name Add-CTTag -Value Add-CTResourceTag
Set-Alias -Name Find-CTEvents -Value Find-CTEvent
Set-Alias -Name Get-CTEventSelectors -Value Get-CTEventSelector
Set-Alias -Name Get-CTTag -Value Get-CTResourceTag
Set-Alias -Name Remove-CTTag -Value Remove-CTResourceTag
Set-Alias -Name Write-CTEventSelectors -Value Write-CTEventSelector

# CloudWatch
Set-Alias -Name Get-CWMetrics -Value Get-CWMetricList
Set-Alias -Name Get-CWMetricStatistics -Value Get-CWMetricStatistic

# CloudWatchLogs
Set-Alias -Name Get-CWLExportTasks -Value Get-CWLExportTask
Set-Alias -Name Get-CWLLogEvents -Value Get-CWLLogEvent
Set-Alias -Name Get-CWLLogGroups -Value Get-CWLLogGroup
Set-Alias -Name Get-CWLLogStreams -Value Get-CWLLogStream
Set-Alias -Name Get-CWLMetricFilters -Value Get-CWLMetricFilter
Set-Alias -Name Get-CWLSubscriptionFilters -Value Get-CWLSubscriptionFilter
Set-Alias -Name Write-CWLLogEvents -Value Write-CWLLogEvent

# CodeDeploy
Set-Alias -Name Get-CDApplications -Value Get-CDApplicationBatch
Set-Alias -Name Get-CDDeployments -Value Get-CDDeploymentBatch

# CodePipeline
Set-Alias -Name Get-CPActionableJobs -Value Get-CPActionableJobList
Set-Alias -Name Get-CPActionableThirdPartyJobs -Value Get-CPActionableThirdPartyJobList
Set-Alias -Name Get-CPJobDetails -Value Get-CPJobDetail
Set-Alias -Name Get-CPThirdPartyJobDetails -Value Get-CPThirdPartyJobDetail

# ConfigService
Set-Alias -Name Get-CFGConfigRules -Value Get-CFGConfigRule
Set-Alias -Name Get-CFGConfigurationRecorders -Value Get-CFGConfigurationRecorder
Set-Alias -Name Get-CFGDeliveryChannels -Value Get-CFGDeliveryChannel
Set-Alias -Name Write-CFGEvaluations -Value Write-CFGEvaluation

# CostAndUsageReport
Set-Alias -Name Get-CURReportDefinitions -Value Get-CURReportDefinition

# DataPipeline
Set-Alias -Name Add-DPTags -Value Add-DPResourceTag
Set-Alias -Name Remove-DPTags -Value Remove-DPResourceTag

# DirectConnect
Set-Alias -Name Get-DCLocations -Value Get-DCLocation

# DirectoryService
Set-Alias -Name Add-DSIpRoutes -Value Add-DSIpRoute
Set-Alias -Name Get-DSIpRoutes -Value Get-DSIpRouteList
Set-Alias -Name Remove-DSIpRoutes -Value Remove-DSIpRoute

# DynamoDBv2
Set-Alias -Name Get-DDBBackupsList -Value Get-DDBBackupList
Set-Alias -Name Get-DDBTables -Value Get-DDBTableList
Set-Alias -Name Get-GlobalTablesList -Value Get-GlobalTableList

# EC2
Set-Alias -Name Confirm-EC2EndpointConnection -Value Approve-EC2EndpointConnection
Set-Alias -Name Confirm-EC2ReservedInstancesExchangeQuote -Value Approve-EC2ReservedInstancesExchangeQuote
Set-Alias -Name Confirm-EC2TransitGatewayPeeringAttachment -Value Approve-EC2TransitGatewayPeeringAttachment
Set-Alias -Name Confirm-EC2TransitGatewayVpcAttachment -Value Approve-EC2TransitGatewayVpcAttachment
Set-Alias -Name Confirm-EC2VpcPeeringConnection -Value Approve-EC2VpcPeeringConnection
Set-Alias -Name Edit-EC2Hosts -Value Edit-EC2Host
Set-Alias -Name Get-EC2AccountAttributes -Value Get-EC2AccountAttribute
Set-Alias -Name Get-EC2ExportTasks -Value Get-EC2ExportTask
Set-Alias -Name Get-EC2FlowLogs -Value Get-EC2FlowLog
Set-Alias -Name Get-EC2Hosts -Value Get-EC2Host
Set-Alias -Name Get-EC2ReservedInstancesModifications -Value Get-EC2ReservedInstancesModification
Set-Alias -Name Get-EC2Snapshots -Value Get-EC2Snapshot
Set-Alias -Name Get-EC2VpcPeeringConnections -Value Get-EC2VpcPeeringConnection
Set-Alias -Name New-EC2FlowLogs -Value New-EC2FlowLog
Set-Alias -Name New-EC2Hosts -Value New-EC2Host
Set-Alias -Name ReleaseHosts -Value Remove-EC2Host
Set-Alias -Name Remove-EC2FlowLogs -Value Remove-EC2FlowLog

# ECS
Set-Alias -Name Get-ECSClusters -Value Get-ECSClusterList
Set-Alias -Name Get-ECSContainerInstances -Value Get-ECSContainerInstanceList
Set-Alias -Name Get-ECSTaskDefinitionFamilies -Value Get-ECSTaskDefinitionFamilyList
Set-Alias -Name Get-ECSTaskDefinitions -Value Get-ECSTaskDefinitionList
Set-Alias -Name Get-ECSTasks -Value Get-ECSTaskList

# ElastiCache
Set-Alias -Name Get-ECCacheEngineVersions -Value Get-ECCacheEngineVersion
Set-Alias -Name Get-ECCacheSubnetGroups -Value Get-ECCacheSubnetGroup
Set-Alias -Name Get-ECReplicationGroups -Value Get-ECReplicationGroup
Set-Alias -Name Get-ECSnapshots -Value Get-ECSnapshot

# ElasticBeanstalk
Set-Alias -Name Get-EBApplications -Value Get-EBApplication
Set-Alias -Name Get-EBApplicationVersions -Value Get-EBApplicationVersion
Set-Alias -Name Get-EBAvailableSolutionStack -Value Get-EBAvailableSolutionStackList
Set-Alias -Name Get-EBConfigurationOptions -Value Get-EBConfigurationOption
Set-Alias -Name Get-EBConfigurationSettings -Value Get-EBConfigurationSetting
Set-Alias -Name Get-EBEnvironmentResources -Value Get-EBEnvironmentResource
Set-Alias -Name Set-EBEnvironmentCNAMEs -Value Set-EBEnvironmentCNAME
Set-Alias -Name Test-EBConfigurationSettings -Value Test-EBConfigurationSetting

# ElasticLoadBalancing
Set-Alias -Name Add-ELBTags -Value Add-ELBResourceTag
Set-Alias -Name Get-ELBTags -Value Get-ELBResourceTag
Set-Alias -Name Remove-ELBTags -Value Remove-ELBResourceTag

# ElasticMapReduce
Set-Alias -Name Add-EMRTag -Value Add-EMRResourceTag
Set-Alias -Name Get-EMRBootstrapActions -Value Get-EMRBootstrapActionList
Set-Alias -Name Get-EMRClusters -Value Get-EMRClusterList
Set-Alias -Name Get-EMRInstanceFleets -Value Get-EMRInstanceFleetList
Set-Alias -Name Get-EMRInstanceGroups -Value Get-EMRInstanceGroupList
Set-Alias -Name Get-EMRInstances -Value Get-EMRInstanceList
Set-Alias -Name Get-EMRSteps -Value Get-EMRStepList
Set-Alias -Name Remove-EMRTag -Value Remove-EMRResourceTag
Set-Alias -Name Set-EMRVisibleToAllUsers -Value Set-EMRVisibleToAllUser
Set-Alias -Name Stop-EMRSteps -Value Stop-EMRStep

# Elasticsearch
Set-Alias -Name Add-ESTag -Value Add-ESResourceTag
Set-Alias -Name Get-ESTag -Value Get-ESResourceTag
Set-Alias -Name Remove-ESTag -Value Remove-ESResourceTag

# ElasticTranscoder
Set-Alias -Name Update-ETSPipelineNotifications -Value Update-ETSPipelineNotification

# Glacier
Set-Alias -Name Get-GLCVaultTagsList -Value Get-GLCVaultTagList

# Glue
Set-Alias -Name Get-GLUECrawlerMetricsList -Value Get-GLUECrawlerMetricList

# IdentityManagement
Set-Alias -Name Get-IAMAccountAuthorizationDetails -Value Get-IAMAccountAuthorizationDetail
Set-Alias -Name Get-IAMAttachedGroupPolicies -Value Get-IAMAttachedGroupPolicyList
Set-Alias -Name Get-IAMAttachedRolePolicies -Value Get-IAMAttachedRolePolicyList
Set-Alias -Name Get-IAMAttachedUserPolicies -Value Get-IAMAttachedUserPolicyList
Set-Alias -Name Get-IAMGroupPolicies -Value Get-IAMGroupPolicyList
Set-Alias -Name Get-IAMGroups -Value Get-IAMGroupList
Set-Alias -Name Get-IAMInstanceProfiles -Value Get-IAMInstanceProfileList
Set-Alias -Name Get-IAMOpenIDConnectProviders -Value Get-IAMOpenIDConnectProviderList
Set-Alias -Name Get-IAMPolicies -Value Get-IAMPolicyList
Set-Alias -Name Get-IAMPolicyVersions -Value Get-IAMPolicyVersionList
Set-Alias -Name Get-IAMRolePolicies -Value Get-IAMRolePolicyList
Set-Alias -Name Get-IAMRoles -Value Get-IAMRoleList
Set-Alias -Name Get-IAMSAMLProviders -Value Get-IAMSAMLProviderList
Set-Alias -Name Get-IAMServerCertificates -Value Get-IAMServerCertificateList
Set-Alias -Name Get-IAMUserPolicies -Value Get-IAMUserPolicyList
Set-Alias -Name Get-IAMUsers -Value Get-IAMUserList

# IoT
Set-Alias -Name Get-IOTAttachedPoliciesList -Value Get-IOTAttachedPolicyList
Set-Alias -Name Get-IOTAuthorizersList -Value Get-IOTAuthorizerList
Set-Alias -Name Get-IOTIndicesList -Value Get-IOTIndexList
Set-Alias -Name Get-IOTJobsList -Value Get-IOTJobList
Set-Alias -Name Get-IOTLoggingOptions -Value Get-IOTLoggingOption
Set-Alias -Name Get-IOTPolicyPrincipalsList -Value Get-IOTPolicyPrincipalList
Set-Alias -Name Get-IOTRoleAliasesList -Value Get-IOTRoleAliasList
Set-Alias -Name Get-IOTThingGroupsList -Value Get-IOTThingGroupList
Set-Alias -Name Get-IOTThingRegistrationTaskReportsList -Value Get-IOTThingRegistrationTaskReportList
Set-Alias -Name Get-IOTThingRegistrationTasksList -Value Get-IOTThingRegistrationTaskList
Set-Alias -Name Get-IOTThingTypesList -Value Get-IOTThingTypeList
Set-Alias -Name Get-IOTV2LoggingLevelsList -Value Get-IOTV2LoggingLevelList
Set-Alias -Name Get-IOTViolationEventsList -Value Get-IOTViolationEventList
Set-Alias -Name Set-IOTLoggingOptions -Value Set-IOTLoggingOption

# KeyManagementService
Set-Alias -Name Get-KMSAliases -Value Get-KMSAliasList
Set-Alias -Name Get-KMSGrants -Value Get-KMSGrantList
Set-Alias -Name Get-KMSKeyPolicies -Value Get-KMSKeyPolicyList
Set-Alias -Name Get-KMSKeys -Value Get-KMSKeyList

# Kinesis
Set-Alias -Name Get-KINStreams -Value Get-KINStreamList

# Lambda
Set-Alias -Name Get-LMEventSourceMappings -Value Get-LMEventSourceMappingList
Set-Alias -Name Get-LMFunctions -Value Get-LMFunctionList

# LexModelsV2
Set-Alias -Name Build-LMBV2BotLocale -Value Invoke-LMBV2BuildBotLocale

# MachineLearning
Set-Alias -Name Add-MLTag -Value Add-MLResourceTag
Set-Alias -Name Get-MLBatchPredictions -Value Get-MLBatchPredictionList
Set-Alias -Name Get-MLDataSources -Value Get-MLDataSourceList
Set-Alias -Name Get-MLEvaluations -Value Get-MLEvaluationList
Set-Alias -Name Get-MLModels -Value Get-MLModelList
Set-Alias -Name Get-MLTag -Value Get-MLResourceTag
Set-Alias -Name Remove-MLTag -Value Remove-MLResourceTag

# OpenSearchService
Set-Alias -Name Add-ESTag -Value Add-OSResourceTag
Set-Alias -Name Get-ESTag -Value Get-OSResourceTag
Set-Alias -Name Remove-ESTag -Value Remove-OSResourceTag

# OpsWorks
Set-Alias -Name Get-OPSApps -Value Get-OPSApp
Set-Alias -Name Get-OPSCommands -Value Get-OPSCommand
Set-Alias -Name Get-OPSDeployments -Value Get-OPSDeployment
Set-Alias -Name Get-OPSElasticIps -Value Get-OPSElasticIp
Set-Alias -Name Get-OPSElasticLoadBalancers -Value Get-OPSElasticLoadBalancer
Set-Alias -Name Get-OPSInstances -Value Get-OPSInstance
Set-Alias -Name Get-OPSLayers -Value Get-OPSLayer
Set-Alias -Name Get-OPSPermissions -Value Get-OPSPermission
Set-Alias -Name Get-OPSRaidArrays -Value Get-OPSRaidArray
Set-Alias -Name Get-OPSRdsDbInstances -Value Get-OPSRdsDbInstance
Set-Alias -Name Get-OPSServiceErrors -Value Get-OPSServiceError
Set-Alias -Name Get-OPSStackProvisioningParameters -Value Get-OPSStackProvisioningParameter
Set-Alias -Name Get-OPSStacks -Value Get-OPSStack
Set-Alias -Name Get-OPSUserProfiles -Value Get-OPSUserProfile
Set-Alias -Name Get-OPSVolumes -Value Get-OPSVolume

# Organizations
Set-Alias -Name Enable-ORGAllFeatures -Value Enable-ORGAllFeature

# RDS
Set-Alias -Name Get-RDSAccountAttributes -Value Get-RDSAccountAttribute
Set-Alias -Name Get-RDSCertificates -Value Get-RDSCertificate
Set-Alias -Name Get-RDSDBLogFiles -Value Get-RDSDBLogFile
Set-Alias -Name Get-RDSDBSnapshotAttributes -Value Get-RDSDBSnapshotAttribute
Set-Alias -Name Get-RDSEventCategories -Value Get-RDSEventCategory
Set-Alias -Name Get-RDSEventSubscriptions -Value Get-RDSEventSubscription
Set-Alias -Name Get-RDSPendingMaintenanceActions -Value Get-RDSPendingMaintenanceAction
Set-Alias -Name Get-RDSReservedDBInstancesOffering -Value New-RDSReservedDBInstancesOfferingPurchase
Set-Alias -Name Get-RDSReservedDBInstancesOfferings -Value Get-RDSReservedDBInstancesOfferingList

# RDSDataService
Set-Alias -Name Begin-RDSDTransaction -Value Start-RDSDTransaction
Set-Alias -Name Commit-RDSDTransaction -Value Confirm-RDSDTransaction
Set-Alias -Name Rollback-RDSDTransaction -Value Reset-RDSDTransaction

# Redshift
Set-Alias -Name Edit-RSClusterIamRoles -Value Edit-RSClusterIamRole
Set-Alias -Name Get-RSClusterParameterGroups -Value Get-RSClusterParameterGroup
Set-Alias -Name Get-RSClusterParameters -Value Get-RSClusterParameter
Set-Alias -Name Get-RSClusters -Value Get-RSCluster
Set-Alias -Name Get-RSClusterSecurityGroups -Value Get-RSClusterSecurityGroup
Set-Alias -Name Get-RSClusterSnapshots -Value Get-RSClusterSnapshot
Set-Alias -Name Get-RSClusterSubnetGroups -Value Get-RSClusterSubnetGroup
Set-Alias -Name Get-RSClusterVersions -Value Get-RSClusterVersion
Set-Alias -Name Get-RSDefaultClusterParameters -Value Get-RSDefaultClusterParameter
Set-Alias -Name Get-RSEventCategories -Value Get-RSEventCategory
Set-Alias -Name Get-RSEvents -Value Get-RSEvent
Set-Alias -Name Get-RSEventSubscriptions -Value Get-RSEventSubscription
Set-Alias -Name Get-RSHsmClientCertificates -Value Get-RSHsmClientCertificate
Set-Alias -Name Get-RSHsmConfigurations -Value Get-RSHsmConfiguration
Set-Alias -Name Get-RSOrderableClusterOptions -Value Get-RSOrderableClusterOption
Set-Alias -Name Get-RSReservedNodeOfferings -Value Get-RSReservedNodeOffering
Set-Alias -Name Get-RSReservedNodes -Value Get-RSReservedNode
Set-Alias -Name Get-RSTags -Value Get-RSResourceTag
Set-Alias -Name New-RSTags -Value New-RSResourceTag
Set-Alias -Name Remove-RSTags -Value Remove-RSResourceTag

# Rekognition
Set-Alias -Name Get-REKStreamProcessorsList -Value Get-REKStreamProcessorList

# Route53
Set-Alias -Name Get-R53CheckerIpRanges -Value Get-R53CheckerIpRange
Set-Alias -Name Get-R53GeoLocations -Value Get-R53GeoLocationList
Set-Alias -Name Get-R53HealthChecks -Value Get-R53HealthCheckList
Set-Alias -Name Get-R53HostedZones -Value Get-R53HostedZoneList
Set-Alias -Name Get-R53ReusableDelegationSets -Value Get-R53ReusableDelegationSetList
Set-Alias -Name Get-R53TagsForResources -Value Get-R53TagsForResourceList
Set-Alias -Name Get-R53TrafficPolicies -Value Get-R53TrafficPolicyList
Set-Alias -Name Get-R53TrafficPolicyInstances -Value Get-R53TrafficPolicyInstanceList
Set-Alias -Name Get-R53TrafficPolicyVersions -Value Get-R53TrafficPolicyVersionList

# Route53Domains
Set-Alias -Name Get-R53DDomainAvailability -Value Test-R53DDomainAvailability
Set-Alias -Name Get-R53DDomains -Value Get-R53DDomainList
Set-Alias -Name Get-R53DOperations -Value Get-R53DOperationList
Set-Alias -Name Update-R53DDomainNameservers -Value Update-R53DDomainNameserver

# S3
Set-Alias -Name Remove-S3MultipartUploads -Value Remove-S3MultipartUpload

# ServiceCatalog
Set-Alias -Name Get-SCAcceptedPortfolioSharesList -Value Get-SCAcceptedPortfolioShareList
Set-Alias -Name Get-SCProductPortfoliosList -Value Get-SCProductPortfolioList

# SimpleEmail
Set-Alias -Name Get-SESIdentityMailFromDomainAttributes -Value Get-SESIdentityMailFromDomainAttribute
Set-Alias -Name Get-SESReceiptFilters -Value Get-SESReceiptFilterList
Set-Alias -Name Get-SESReceiptRuleSets -Value Get-SESReceiptRuleSetList
Set-Alias -Name Get-SESSendStatistics -Value Get-SESSendStatistic

# SimpleNotificationService
Set-Alias -Name Get-SNSEndpointAttributes -Value Get-SNSEndpointAttribute
Set-Alias -Name Get-SNSPlatformApplicationAttributes -Value Get-SNSPlatformApplicationAttribute
Set-Alias -Name Get-SNSPlatformApplications -Value Get-SNSPlatformApplicationList
Set-Alias -Name Get-SNSSMSAttributes -Value Get-SNSSMSAttribute
Set-Alias -Name Set-SNSEndpointAttributes -Value Set-SNSEndpointAttribute
Set-Alias -Name Set-SNSPlatformApplicationAttributes -Value Set-SNSPlatformApplicationAttribute
Set-Alias -Name Set-SNSSMSAttributes -Value Set-SNSSMSAttribute

# SimpleSystemsManagement
Set-Alias -Name Get-SSMComplianceItemsList -Value Get-SSMComplianceItemList
Set-Alias -Name Get-SSMComplianceSummariesList -Value Get-SSMComplianceSummaryList
Set-Alias -Name Get-SSMInventoryEntriesList -Value Get-SSMInventoryEntryList
Set-Alias -Name Get-SSMMaintenanceWindowTargets -Value Get-SSMMaintenanceWindowTarget
Set-Alias -Name Get-SSMParameterNameList -Value Get-SSMParameterValue
Set-Alias -Name Get-SSMResourceComplianceSummariesList -Value Get-SSMResourceComplianceSummaryList

# Snowball
Set-Alias -Name Get-SNOWJobsList -Value Get-SNOWJobList

# SQS
Set-Alias -Name Get-SQSDeadLetterSourceQueues -Value Get-SQSDeadLetterSourceQueue

# StorageGateway
Set-Alias -Name Get-SGChapCredentials -Value Get-SGChapCredential
Set-Alias -Name Get-SGResourceTags -Value Get-SGResourceTag
Set-Alias -Name Get-SGTapeArchives -Value Get-SGTapeArchiveList
Set-Alias -Name Get-SGTapeRecoveryPoints -Value Get-SGTapeRecoveryPointList
Set-Alias -Name Get-SGTapes -Value Get-SGTapeList
Set-Alias -Name Get-SGVolumeInitiators -Value Get-SGVolumeInitiatorList
Set-Alias -Name Get-SGVTLDevices -Value Get-SGVTLDevice
Set-Alias -Name New-SGTapes -Value New-SGTape
Set-Alias -Name Remove-SGChapCredentials -Value Remove-SGChapCredential
Set-Alias -Name Update-SGChapCredentials -Value Update-SGChapCredential

# WellArchitected
Set-Alias -Name Add-WATLense -Value Register-WATLens
Set-Alias -Name Get-WATLenseList -Value Get-WATLensList
Set-Alias -Name Remove-WATLense -Value Unregister-WATLens

# WorkSpaces
Set-Alias -Name Get-WKSWorkspaceBundles -Value Get-WKSWorkspaceBundle
Set-Alias -Name Get-WKSWorkspaceDirectories -Value Get-WKSWorkspaceDirectory
Set-Alias -Name Get-WKSWorkspaces -Value Get-WKSWorkspace

Export-ModuleMember -Alias *
# SIG # Begin signature block
# MIIudwYJKoZIhvcNAQcCoIIuaDCCLmQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCD1ZqkytR8S06Yv
# v5kn/1wZtqzkoQcu0cGK3aVTH9ttMaCCE+owggXAMIIEqKADAgECAhAP0bvKeWvX
# +N1MguEKmpYxMA0GCSqGSIb3DQEBCwUAMGwxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xKzApBgNV
# BAMTIkRpZ2lDZXJ0IEhpZ2ggQXNzdXJhbmNlIEVWIFJvb3QgQ0EwHhcNMjIwMTEz
# MDAwMDAwWhcNMzExMTA5MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMM
# RGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQD
# ExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwggIiMA0GCSqGSIb3DQEBAQUAA4IC
# DwAwggIKAoICAQC/5pBzaN675F1KPDAiMGkz7MKnJS7JIT3yithZwuEppz1Yq3aa
# za57G4QNxDAf8xukOBbrVsaXbR2rsnnyyhHS5F/WBTxSD1Ifxp4VpX6+n6lXFllV
# cq9ok3DCsrp1mWpzMpTREEQQLt+C8weE5nQ7bXHiLQwb7iDVySAdYyktzuxeTsiT
# +CFhmzTrBcZe7FsavOvJz82sNEBfsXpm7nfISKhmV1efVFiODCu3T6cw2Vbuyntd
# 463JT17lNecxy9qTXtyOj4DatpGYQJB5w3jHtrHEtWoYOAMQjdjUN6QuBX2I9YI+
# EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsDdV14Ztk6MUSaM0C/CNdaSaTC5qmgZ92k
# J7yhTzm1EVgX9yRcRo9k98FpiHaYdj1ZXUJ2h4mXaXpI8OCiEhtmmnTK3kse5w5j
# rubU75KSOp493ADkRSWJtppEGSt+wJS00mFt6zPZxd9LBADMfRyVw4/3IbKyEbe7
# f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hkpjPRiQfhvbfmQ6QYuKZ3AeEPlAwhHbJU
# KSWJbOUOUlFHdL4mrLZBdd56rF+NP8m800ERElvlEFDrMcXKchYiCd98THU/Y+wh
# X8QgUWtvsauGi0/C1kVfnSD8oR7FwI+isX4KJpn15GkvmB0t9dmpsh3lGwIDAQAB
# o4IBZjCCAWIwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wHwYDVR0jBBgwFoAUsT7DaQP4v0cB1JgmGggC72NkK8MwDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMH8GCCsGAQUFBwEBBHMwcTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEkGCCsGAQUFBzAC
# hj1odHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRIaWdoQXNzdXJh
# bmNlRVZSb290Q0EuY3J0MEsGA1UdHwREMEIwQKA+oDyGOmh0dHA6Ly9jcmwzLmRp
# Z2ljZXJ0LmNvbS9EaWdpQ2VydEhpZ2hBc3N1cmFuY2VFVlJvb3RDQS5jcmwwHAYD
# VR0gBBUwEzAHBgVngQwBAzAIBgZngQwBBAEwDQYJKoZIhvcNAQELBQADggEBAEHx
# qRH0DxNHecllao3A7pgEpMbjDPKisedfYk/ak1k2zfIe4R7sD+EbP5HU5A/C5pg0
# /xkPZigfT2IxpCrhKhO61z7H0ZL+q93fqpgzRh9Onr3g7QdG64AupP2uU7SkwaT1
# IY1rzAGt9Rnu15ClMlIr28xzDxj4+87eg3Gn77tRWwR2L62t0+od/P1Tk+WMieNg
# GbngLyOOLFxJy34riDkruQZhiPOuAnZ2dMFkkbiJUZflhX0901emWG4f7vtpYeJa
# 3Cgh6GO6Ps9W7Zrk9wXqyvPsEt84zdp7PiuTUy9cUQBY3pBIowrHC/Q7bVUx8ALM
# R3eWUaNetbxcyEMRoacwggawMIIEmKADAgECAhAIrUCyYNKcTJ9ezam9k67ZMA0G
# CSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0
# IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0zNjA0MjgyMzU5NTla
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDVtC9C
# 0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0JAfhS0/TeEP0F9ce
# 2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJrQ5qZ8sU7H/Lvy0da
# E6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhFLqGfLOEYwhrMxe6T
# SXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+FLEikVoQ11vkunKoA
# FdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh3K3kGKDYwSNHR7Oh
# D26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJwZPt4bRc4G/rJvmM
# 1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQayg9Rc9hUZTO1i4F4z
# 8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbIYViY9XwCFjyDKK05
# huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchApQfDVxW0mdmgRQRNY
# mtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRroOBl8ZhzNeDhFMJlP
# /2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IBWTCCAVUwEgYDVR0T
# AQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHwYD
# VR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNV
# HR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRU
# cnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAEDMAgGBmeBDAEEATAN
# BgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql+Eg08yy25nRm95Ry
# sQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFFUP2cvbaF4HZ+N3HL
# IvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1hmYFW9snjdufE5Btf
# Q/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3RywYFzzDaju4ImhvTnh
# OE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5UbdldAhQfQDN8A+KVssIh
# dXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw8MzK7/0pNVwfiThV
# 9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnPLqR0kq3bPKSchh/j
# wVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatEQOON8BUozu3xGFYH
# Ki8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bnKD+sEq6lLyJsQfmC
# XBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQjiWQ1tygVQK+pKHJ6l
# /aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbqyK+p/pQd52MbOoZW
# eE4wggduMIIFVqADAgECAhAOG4Qdo7UmBpSv170eUaMrMA0GCSqGSIb3DQEBCwUA
# MGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UE
# AxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcgUlNBNDA5NiBTSEEz
# ODQgMjAyMSBDQTEwHhcNMjQwODAyMDAwMDAwWhcNMjUwODAxMjM1OTU5WjCB9jET
# MBEGCysGAQQBgjc8AgEDEwJVUzEZMBcGCysGAQQBgjc8AgECEwhEZWxhd2FyZTEd
# MBsGA1UEDwwUUHJpdmF0ZSBPcmdhbml6YXRpb24xEDAOBgNVBAUTBzQxNTI5NTQx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdTZWF0
# dGxlMSIwIAYDVQQKExlBbWF6b24gV2ViIFNlcnZpY2VzLCBJbmMuMRcwFQYDVQQL
# Ew5TREtzIGFuZCBUb29sczEiMCAGA1UEAxMZQW1hem9uIFdlYiBTZXJ2aWNlcywg
# SW5jLjCCAaIwDQYJKoZIhvcNAQEBBQADggGPADCCAYoCggGBAJn5K00vaam9Tsax
# bhWuOwBweiOIeGUkpi0F5SYcPijYzpnd7vS0G3WYbFuSTGKipaRe37VDHdNa9Y1F
# faRSBrKmeNytBzNsnIUtiKl5OWuQkbaNcH/8XHwPOf6szaqz6wnnkhj0Bv0zA+Ih
# IVAyPg7T8bqJRkGfOf5ugIH06fPVFj1KWuugiXNs1/M4/FLyBLsSJZbfvID+TVWO
# 2YjFBLDDVrOB7rw22KJYl4w1q+wfUUm05uRX5I+uLiRaT88l1MZHLwHg1nuL0Vm9
# t41X2xTOn4QeqxIXo1BbcVfiyjPogrU9xHUs2B1JyEVZWjv4VUwfOW0X3er1Ukwn
# Kqxsjg/2ikAT4oRjFgWnLsU0VoRDkkShhfVtC5pSB6v/v0gzgReQNqElCVcKwOHj
# fiTzbRRWHFwYzNwEqnSAhC+qB/zYXWg9KBF1DtVcWVLaHMXuLn0plnHWA/AoPZcl
# hc7HjClr15RcrHl6pcclBHtRBtJkX7jLlC7cAWkob+4Wp/QyVwIDAQABo4ICAjCC
# Af4wHwYDVR0jBBgwFoAUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHQYDVR0OBBYEFAa4
# CewhP0BkYi71XHKKI9o8p1BMMD0GA1UdIAQ2MDQwMgYFZ4EMAQMwKTAnBggrBgEF
# BQcCARYbaHR0cDovL3d3dy5kaWdpY2VydC5jb20vQ1BTMA4GA1UdDwEB/wQEAwIH
# gDATBgNVHSUEDDAKBggrBgEFBQcDAzCBtQYDVR0fBIGtMIGqMFOgUaBPhk1odHRw
# Oi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmlu
# Z1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNybDBToFGgT4ZNaHR0cDovL2NybDQuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hB
# Mzg0MjAyMUNBMS5jcmwwgZQGCCsGAQUFBwEBBIGHMIGEMCQGCCsGAQUFBzABhhho
# dHRwOi8vb2NzcC5kaWdpY2VydC5jb20wXAYIKwYBBQUHMAKGUGh0dHA6Ly9jYWNl
# cnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNB
# NDA5NlNIQTM4NDIwMjFDQTEuY3J0MAkGA1UdEwQCMAAwDQYJKoZIhvcNAQELBQAD
# ggIBAISiRgUmPdqs8OdhLLJ8Blj9EmNwt3MNQszq45nw9ApvgRRXBYFTA/5JFJQv
# 4k3qqAeOlt0vbGnzDHVzWq7JEGJZrUn7qfkmj4jflPJ1c6iOCUZFb8+x+45K/9ks
# o4yS4Y3M2gCDKJMrKmgyhm/qZL2oXbViT3XB4iVYr/+eHLf+146UWYrYtR5clim9
# FM1tkXV9n4gk+h5FRgSDXoqSiwoyM60ziNutQAKsNAHjnazBWRluKwhtpVMRuHu8
# 1SbIeTJ/xz0F2P90vmMu2SBhtsnO4QL3uMznLJ6qvAQVfny/T2bMSSPROHIXSDvA
# qCThkA49Gi/5NXKmMs8ukZzLOkTEx8V5uKxEf4gI9q17oLYG8oX5e+FlldVpxRRf
# kru1RtPu4MCAzvLYTdLgk9Rovglztgic8gQNSQO/pjHX7zAZ5Ys+M4japyzrzhwK
# yCwfnKWAv8b+5pqSsJh4bdoXQtGBP/QOiKjD3+ip/D36hw4ZKYoVu5XJu+rnY+or
# 8dXYA9uaZYrVGLH16W8bidzPT3wCcBOWcod4WHQW+Rk2AoRLAj2Nj+TxwlDIDQkA
# SD/n7Sm0FLFzjBmPD5YfFu58jefNV2HW3aBFuM+1e0VyjuRPz+dmP0vG8HVL8ste
# NxL0ev/CF619Ef4FsUgUwTSV0IvDtgYkxlbtwuzHqYSWUFo4MYIZ4zCCGd8CAQEw
# fTBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNV
# BAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgQ29kZSBTaWduaW5nIFJTQTQwOTYgU0hB
# Mzg0IDIwMjEgQ0ExAhAOG4Qdo7UmBpSv170eUaMrMA0GCWCGSAFlAwQCAQUAoHww
# EAYKKwYBBAGCNwIBDDECMAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIOdgOXHq
# qR5FalKdUHuCKBrxfAoKznOT61XfEAYPF6+cMA0GCSqGSIb3DQEBAQUABIIBgAza
# Yyg4cgSyy1fWpEBNQ7efjpgVMl+IkKCm6jbL8UX+n+Z4FxW5n37UYARrjpasKNud
# PM1jn3K0Cvl2LQirb+UhSj9+SNoRnaPhOO95S7JKIcYVMv0A9ofcHdzH4El1KJAs
# b3zCVnqpdVzs+fhHHHtQ6ElSMQ9RinzA5Vie5jzxDxBz3dx9PLaTWVKIbCxKi7Q/
# vTSjGOChUMJCaJSIHEtg0D7uv+UcpwA/42QDp2yMol60yAeCjgtzY4tGt9HDGIwA
# 3NEQDg6nGGkKAJTZ+7XbHgLR79Z+oovx7vy9lF1Q26W2+jyM+f9IUqMFu5G+gQ1m
# kkEy6khiZrJtzsXfQSTr0zXJTnvCv8Fr5YmIrfld2ksghty0ntWDGzbRVELy5T1l
# AxYjtAuMadmatnaILDzl5nB02T6FIJRwUvdg1tEPbKnLxvEZnEA5HAgjC/4N2E7C
# jsZ6rSbWz6DFVYX2a1caGZTYnv14fGY+w/r5IXrRN3r0PntD3DbxDE1dV0RMDaGC
# Fzkwghc1BgorBgEEAYI3AwMBMYIXJTCCFyEGCSqGSIb3DQEHAqCCFxIwghcOAgED
# MQ8wDQYJYIZIAWUDBAIBBQAwdwYLKoZIhvcNAQkQAQSgaARmMGQCAQEGCWCGSAGG
# /WwHATAxMA0GCWCGSAFlAwQCAQUABCBFC4U7plu0SlRw3IEx8vnAU/zTM3jYbZcX
# 9Fy8iKtvDAIQZXe1ZkRtdWB8OXNvhCRsOBgPMjAyNTAyMDcyMjI1MzdaoIITAzCC
# BrwwggSkoAMCAQICEAuuZrxaun+Vh8b56QTjMwQwDQYJKoZIhvcNAQELBQAwYzEL
# MAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTswOQYDVQQDEzJE
# aWdpQ2VydCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVTdGFtcGluZyBD
# QTAeFw0yNDA5MjYwMDAwMDBaFw0zNTExMjUyMzU5NTlaMEIxCzAJBgNVBAYTAlVT
# MREwDwYDVQQKEwhEaWdpQ2VydDEgMB4GA1UEAxMXRGlnaUNlcnQgVGltZXN0YW1w
# IDIwMjQwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC+anOf9pUhq5Yw
# ultt5lmjtej9kR8YxIg7apnjpcH9CjAgQxK+CMR0Rne/i+utMeV5bUlYYSuuM4vQ
# ngvQepVHVzNLO9RDnEXvPghCaft0djvKKO+hDu6ObS7rJcXa/UKvNminKQPTv/1+
# kBPgHGlP28mgmoCw/xi6FG9+Un1h4eN6zh926SxMe6We2r1Z6VFZj75MU/HNmtsg
# tFjKfITLutLWUdAoWle+jYZ49+wxGE1/UXjWfISDmHuI5e/6+NfQrxGFSKx+rDdN
# MsePW6FLrphfYtk/FLihp/feun0eV+pIF496OVh4R1TvjQYpAztJpVIfdNsEvxHo
# fBf1BWkadc+Up0Th8EifkEEWdX4rA/FE1Q0rqViTbLVZIqi6viEk3RIySho1XyHL
# IAOJfXG5PEppc3XYeBH7xa6VTZ3rOHNeiYnY+V4j1XbJ+Z9dI8ZhqcaDHOoj5KGg
# 4YuiYx3eYm33aebsyF6eD9MF5IDbPgjvwmnAalNEeJPvIeoGJXaeBQjIK13SlnzO
# DdLtuThALhGtyconcVuPI8AaiCaiJnfdzUcb3dWnqUnjXkRFwLtsVAxFvGqsxUA2
# Jq/WTjbnNjIUzIs3ITVC6VBKAOlb2u29Vwgfta8b2ypi6n2PzP0nVepsFk8nlcuW
# fyZLzBaZ0MucEdeBiXL+nUOGhCjl+QIDAQABo4IBizCCAYcwDgYDVR0PAQH/BAQD
# AgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwIAYDVR0g
# BBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMB8GA1UdIwQYMBaAFLoW2W1NhS9z
# KXaaL3WMaiCPnshvMB0GA1UdDgQWBBSfVywDdw4oFZBmpWNe7k+SH3agWzBaBgNV
# HR8EUzBRME+gTaBLhklodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRU
# cnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3JsMIGQBggrBgEF
# BQcBAQSBgzCBgDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29t
# MFgGCCsGAQUFBzAChkxodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNl
# cnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3J0MA0GCSqG
# SIb3DQEBCwUAA4ICAQA9rR4fdplb4ziEEkfZQ5H2EdubTggd0ShPz9Pce4FLJl6r
# eNKLkZd5Y/vEIqFWKt4oKcKz7wZmXa5VgW9B76k9NJxUl4JlKwyjUkKhk3aYx7D8
# vi2mpU1tKlY71AYXB8wTLrQeh83pXnWwwsxc1Mt+FWqz57yFq6laICtKjPICYYf/
# qgxACHTvypGHrC8k1TqCeHk6u4I/VBQC9VK7iSpU5wlWjNlHlFFv/M93748YTeoX
# U/fFa9hWJQkuzG2+B7+bMDvmgF8VlJt1qQcl7YFUMYgZU1WM6nyw23vT6QSgwX5P
# q2m0xQ2V6FJHu8z4LXe/371k5QrN9FQBhLLISZi2yemW0P8ZZfx4zvSWzVXpAb9k
# 4Hpvpi6bUe8iK6WonUSV6yPlMwerwJZP/Gtbu3CKldMnn+LmmRTkTXpFIEB06nXZ
# rDwhCGED+8RsWQSIXZpuG4WLFQOhtloDRWGoCwwc6ZpPddOFkM2LlTbMcqFSzm4c
# d0boGhBq7vkqI1uHRz6Fq1IX7TaRQuR+0BGOzISkcqwXu7nMpFu3mgrlgbAW+Bzi
# kRVQ3K2YHcGkiKjA4gi4OA/kz1YCsdhIBHXqBzR0/Zd2QwQ/l4Gxftt/8wY3grcc
# /nS//TVkej9nmUYu83BDtccHHXKibMs/yXHhDXNkoPIdynhVAku7aRZOwqw6pDCC
# Bq4wggSWoAMCAQICEAc2N7ckVHzYR6z9KGYqXlswDQYJKoZIhvcNAQELBQAwYjEL
# MAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3
# LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3RlZCBSb290IEc0
# MB4XDTIyMDMyMzAwMDAwMFoXDTM3MDMyMjIzNTk1OVowYzELMAkGA1UEBhMCVVMx
# FzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTswOQYDVQQDEzJEaWdpQ2VydCBUcnVz
# dGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVTdGFtcGluZyBDQTCCAiIwDQYJKoZI
# hvcNAQEBBQADggIPADCCAgoCggIBAMaGNQZJs8E9cklRVcclA8TykTepl1Gh1tKD
# 0Z5Mom2gsMyD+Vr2EaFEFUJfpIjzaPp985yJC3+dH54PMx9QEwsmc5Zt+FeoAn39
# Q7SE2hHxc7Gz7iuAhIoiGN/r2j3EF3+rGSs+QtxnjupRPfDWVtTnKC3r07G1decf
# BmWNlCnT2exp39mQh0YAe9tEQYncfGpXevA3eZ9drMvohGS0UvJ2R/dhgxndX7RU
# CyFobjchu0CsX7LeSn3O9TkSZ+8OpWNs5KbFHc02DVzV5huowWR0QKfAcsW6Th+x
# tVhNef7Xj3OTrCw54qVI1vCwMROpVymWJy71h6aPTnYVVSZwmCZ/oBpHIEPjQ2OA
# e3VuJyWQmDo4EbP29p7mO1vsgd4iFNmCKseSv6De4z6ic/rnH1pslPJSlRErWHRA
# KKtzQ87fSqEcazjFKfPKqpZzQmiftkaznTqj1QPgv/CiPMpC3BhIfxQ0z9JMq++b
# Pf4OuGQq+nUoJEHtQr8FnGZJUlD0UfM2SU2LINIsVzV5K6jzRWC8I41Y99xh3pP+
# OcD5sjClTNfpmEpYPtMDiP6zj9NeS3YSUZPJjAw7W4oiqMEmCPkUEBIDfV8ju2Tj
# Y+Cm4T72wnSyPx4JduyrXUZ14mCjWAkBKAAOhFTuzuldyF4wEr1GnrXTdrnSDmuZ
# DNIztM2xAgMBAAGjggFdMIIBWTASBgNVHRMBAf8ECDAGAQH/AgEAMB0GA1UdDgQW
# BBS6FtltTYUvcyl2mi91jGogj57IbzAfBgNVHSMEGDAWgBTs1+OC0nFdZEzfLmc/
# 57qYrhwPTzAOBgNVHQ8BAf8EBAMCAYYwEwYDVR0lBAwwCgYIKwYBBQUHAwgwdwYI
# KwYBBQUHAQEEazBpMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5j
# b20wQQYIKwYBBQUHMAKGNWh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdp
# Q2VydFRydXN0ZWRSb290RzQuY3J0MEMGA1UdHwQ8MDowOKA2oDSGMmh0dHA6Ly9j
# cmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRSb290RzQuY3JsMCAGA1Ud
# IAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATANBgkqhkiG9w0BAQsFAAOCAgEA
# fVmOwJO2b5ipRCIBfmbW2CFC4bAYLhBNE88wU86/GPvHUF3iSyn7cIoNqilp/GnB
# zx0H6T5gyNgL5Vxb122H+oQgJTQxZ822EpZvxFBMYh0MCIKoFr2pVs8Vc40BIiXO
# lWk/R3f7cnQU1/+rT4osequFzUNf7WC2qk+RZp4snuCKrOX9jLxkJodskr2dfNBw
# CnzvqLx1T7pa96kQsl3p/yhUifDVinF2ZdrM8HKjI/rAJ4JErpknG6skHibBt94q
# 6/aesXmZgaNWhqsKRcnfxI2g55j7+6adcq/Ex8HBanHZxhOACcS2n82HhyS7T6NJ
# uXdmkfFynOlLAlKnN36TU6w7HQhJD5TNOXrd/yVjmScsPT9rp/Fmw0HNT7ZAmyEh
# QNC3EyTN3B14OuSereU0cZLXJmvkOHOrpgFPvT87eK1MrfvElXvtCl8zOYdBeHo4
# 6Zzh3SP9HSjTx/no8Zhf+yvYfvJGnXUsHicsJttvFXseGYs2uJPU5vIXmVnKcPA3
# v5gA3yAWTyf7YGcWoWa63VXAOimGsJigK+2VQbc61RWYMbRiCQ8KvYHZE/6/pNHz
# V9m8BPqC3jLfBInwAM1dwvnQI38AC+R2AibZ8GV2QqYphwlHK+Z/GqSFD/yYlvZV
# VCsfgPrA8g4r5db7qS9EFUrnEw4d2zc4GqEr9u3WfPwwggWNMIIEdaADAgECAhAO
# mxiO+dAt5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUw
# EwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20x
# JDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEw
# MDAwMDBaFw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxE
# aWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMT
# GERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIP
# ADCCAgoCggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprN
# rnsbhA3EMB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVy
# r2iTcMKyunWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4
# IWGbNOsFxl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13j
# rclPXuU15zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4Q
# kXCrVYJBMtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQn
# vKFPObURWBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu
# 5tTvkpI6nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/
# 8tWMcCxBYKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQp
# JYls5Q5SUUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFf
# xCBRa2+xq4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGj
# ggE6MIIBNjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/
# 57qYrhwPTzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAOBgNVHQ8B
# Af8EBAMCAYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2Nz
# cC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2lj
# ZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6
# oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElE
# Um9vdENBLmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEMBQADggEB
# AHCgv0NcVec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxppVCLtpIh3bb0a
# FPQTSnovLbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6mouyXtTP0UNE
# m0Mh65ZyoUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPHh6jSTEAZNUZq
# aVSwuKFWjuyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAcAgPLILCs
# WKAOQGPFmCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg62fC2h5b9W9Fc
# rBjDTZ9ztwGpn1eqXijiuZQxggN2MIIDcgIBATB3MGMxCzAJBgNVBAYTAlVTMRcw
# FQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNlcnQgVHJ1c3Rl
# ZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0ECEAuuZrxaun+Vh8b5
# 6QTjMwQwDQYJYIZIAWUDBAIBBQCggdEwGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJ
# EAEEMBwGCSqGSIb3DQEJBTEPFw0yNTAyMDcyMjI1MzdaMCsGCyqGSIb3DQEJEAIM
# MRwwGjAYMBYEFNvThe5i29I+e+T2cUhQhyTVhltFMC8GCSqGSIb3DQEJBDEiBCAV
# V2oFyRmagK4GFLO27WfnsO6P6lah11UOW32gGACdcTA3BgsqhkiG9w0BCRACLzEo
# MCYwJDAiBCB2dp+o8mMvH0MLOiMwrtZWdf7Xc9sF1mW5BZOYQ4+a2zANBgkqhkiG
# 9w0BAQEFAASCAgB7ADR+RAyZ/z1ONieeQ7iSMPSufhnIQlUhdDl2MEe3rZOmWfDA
# 42aq1nv/xz8RmJKYVznIDCMPtfz1aX8kw+9qmWUtTiGpL16tZfu6tmJA1728nx51
# fDWKuT44O/9X3+6ywcSgKnildUdMtdTrEL/HNjAIze6HpOYcjaQ4yvLOHiIbajVY
# +8Lkgb26lwtzIhw6cmowjLWNnV/UABKeccDKkyksRK3lUbcCl+s1HYYPPUl1t2dH
# OrOIBiHtEo2wq0outRHSGqsEduakc1PqIayHHAK0vUeLnkS4P+kNkftRYW8Oo/CC
# I2VNwST5EqQdn0c7zVq8aRMYCeSPxZet/nBRtSQgjxBeO14q9zYsW79RW3KVvbZ8
# h3o7UUruFBsLOchO4ou7bFJRK9YsJVxXMlC5pXVuf21Pb1Uur8gsw9UR7/jlfM0U
# hAe7io9F8apGpDvJJ2KbGUsQYqUNCi+jPCyZJpeBBHZP1dcvL81vJu+A/r4BHxpk
# DKzvHvIAAR8w5GIE9DRJn5dFTJjlvmduXaGmZV/guEYwCbWxMLZyJMxxZ6pAk6fl
# EpHWxly1bE5GCzNY/plbA7zPiHHTBbiIyPNImljfUjsNW17Fofrsw9MmmOTqGPZN
# /85MURSFPxiBKno8ysh/qhig9m2nHs50+610TyeEAEqem+UqB6GwNMqLwg==
# SIG # End signature block
